function show_hide_menu(a) {
	$('.adm_menu_sub').css('display','none');
	if (a) {
		$('#adm_menu_sub_' + a).css('display','block');
	}
}

function showhide_sidemenu(a) {
	setCookie ('sh_leftmnu', a, 365);
	if (a == 'hide') {
		clearInterval(listcon);
		clearTimeout(listcon);
		sidemenu_width = 0;
		$('.adm_header_left').animate({'line-height':'29px','font-size':'16px'},100,function() {
			$('.adm_header_left').css({'text-align':'left','padding':'0 0 0 20px','width':'180px'});
			$('.adm_header_bottom').animate({'padding':'0 0 0 10px'},100,function(){
				$('.adm_header_bottom').css('width','calc(100% - 10px)');
			});
		});

		//$('.adm_main_btn_left').css('display','none');
		if (sidemenu_position == 'left') {
			$('.adm_main_tab_side').animate({'left':'-200px'},300,function() {
				$('.adm_main_tab_side').css('display','none');
			});
			$('.adm_main_tab_cont').animate({'margin-left':'0'},300,function() {
				//$('.adm_main_btn_right').css('display','block');
				chg_size();
			});
		}
		else {
			$('.adm_main_tab_side').animate({'right':'-200px'},300,function() {
				$('.adm_main_tab_side').css('display','none');
			});
			$('.adm_main_tab_cont').animate({'margin-right':'0'},300,function() {
				//$('.adm_main_btn_right').css('display','block');
				chg_size();
			});
		}
		$('.Lhide').css('display','none');
		$('.Lshow').css('display','block');
	}
	else if (a == 'show') {
		ConnectListChk();
		sidemenu_width = 200;
		if (sidemenu_position == 'left') {
			$('.adm_header_bottom').animate({'padding':'0 0 0 210px'},100,function(){
				$('.adm_header_bottom').css('width','calc(100% - 210px)');
				$('.adm_header_left').animate({'line-height':'65px','font-size':'20px'},100,function() {
					$('.adm_header_left').css({'text-align':'center','padding':'0','width':'200px'});
				});
			});
		}
		else {
			$('.adm_header_left').animate({'line-height':'29px','font-size':'16px'},100,function() {
				$('.adm_header_left').css({'text-align':'left','padding':'0 0 0 20px','width':'180px'});
				$('.adm_header_bottom').animate({'padding':'0 0 0 10px'},100,function(){
					$('.adm_header_bottom').css('width','calc(100% - 10px)');
				});
			});
		}
		//$('.adm_main_btn_right').css('display','none');
		$('.adm_main_tab_side').css('display','block');
		if (sidemenu_position == 'left') {
			$('.adm_main_tab_cont').animate({'margin-left':'200px'},300,function() {
				//$('.adm_main_tab_side').css('display','block');
				//$('.adm_main_btn_left').css('display','block');
				$('.adm_main_tab_side').animate({'left':'0'},300,function() {});
				chg_size();
			});
		}
		else {
			$('.adm_main_tab_cont').animate({'margin-right':'200px'},300,function() {
				//$('.adm_main_tab_side').css('display','block');
				//$('.adm_main_btn_left').css('display','block');
				$('.adm_main_tab_side').animate({'right':'0'},300,function() {});
				chg_size();
			});
		}
		$('.Lshow').css('display','none');
		$('.Lhide').css('display','block');
	}
}

function resize_chartA() {
	if ($(".main_top1").length > 0) {
		var width = $(".main_top1").css("width");
		//console.log(width);
		$("#container").css("width",width);
		chart.reflow();
	}
}

var sidemenu_width = 200;

function chg_size() {

	var wh = get_wh();
	var width = wh['w'];
	var height = wh['h'];

	var ah_height = parseInt($('.adm_header').css('height'));
	var af_height = parseInt($('.adm_footer').css('height'));
	var amtr_width = width - sidemenu_width - 20;
	//var amtr_width = width - sidemenu_width;
	var amtr_height = height - ah_height - 20;
	//var ambl_top = (height - ah_height - af_height) / 2 - 10;
	var ambl_top = height / 2 - 6;
	//console.log(height + ', ' + ah_height + ', ' + af_height + ', ' + ambl_top);

	$('.adm_main_tab_cont').css('width',amtr_width+'px').css('min-height',amtr_height+'px');
	$('.adm_main_btn_left').css('top',ambl_top+'px');
	$('.adm_main_btn_right').css('top',ambl_top+'px');

	resize_chartA();
}

$(window).load(chg_size).resize(chg_size);

function init_showhide_sidemenu() {
	var shlm = unescape(getCookie('sh_leftmnu'));
	if (shlm == '') shlm = 'show';

	$('.adm_loading').css('display','none');

	if (sidemenu_position == 'left') {
		$('.Lhide').prop('src','./images/leftmenu_hide.jpg');
		$('.Lshow').prop('src','./images/leftmenu_show.jpg');
		$('.adm_main_tab_side').css('left','0');
		$('.adm_main_tab_cont').css('left','0').css('margin','0 0 100px 200px');
	}
	else {
		$('.Lhide').prop('src','./images/rightmenu_hide.jpg');
		$('.Lshow').prop('src','./images/rightmenu_show.jpg');
		$('.adm_main_tab_side').css('right','0');
		$('.adm_main_tab_cont').css('left','0').css('margin','0 200px 100px 0');
	}

	if (shlm == 'show') {
		ConnectListChk();
		sidemenu_width = 200;
		if (sidemenu_position == 'left') {
			$('.adm_header_left').css({'line-height':'65px','font-size':'20px','text-align':'center','padding':'0','width':'200px'});
			$('.adm_header_bottom').css({'width':'calc(100% - 210px)','padding':'0 0 0 210px'});
			//$('.adm_main_btn_right').css('display','none');
			$('.adm_main_tab_cont').css('margin','0 0 0 200px').css('display','block');
		}
		else {
			$('.adm_header_left').css({'line-height':'29px','font-size':'16px','text-align':'left','padding':'0 0 0 20px','width':'180px'});
			$('.adm_header_bottom').css({'width':'calc(100% - 10px)','padding':'0 0 0 10px'});
			//$('.adm_main_btn_right').css('display','block');
			$('.adm_main_tab_cont').css('margint','0 200px 0 0').css('display','block');
		}
		$('.adm_main_tab_side').css('display','block');
		//$('.adm_main_btn_left').css('display','block');
		$('.Lhide').css('display','block');
		$('.adm_sidemenu_showhide').css('display','block');
	}
	else if (shlm == 'hide') {
		clearInterval(listcon);
		clearTimeout(listcon);
		sidemenu_width = 0;
		$('.adm_header_left').css({'line-height':'29px','font-size':'16px','text-align':'left','padding':'0 0 0 20px','width':'180px'});
		$('.adm_header_bottom').css({'width':'calc(100% - 10px)','padding':'0 0 0 10px'});
		//$('.adm_main_btn_right').css('display','block');
		$('.adm_main_tab_cont').css('margin','0 0 100px 0').css('display','block');
		if (sidemenu_position == 'left') {
			$('.adm_main_tab_side').css('left','-200px').css('display','none');
		}
		else {
			$('.adm_main_tab_side').css('right','-200px').css('display','none');
		}
		//$('.adm_main_btn_left').css('display','none');
		$('.Lshow').css('display','block');
		$('.adm_sidemenu_showhide').css('display','block');
	}
	$('.adm_header').css('display','block');
	setCookie ('sh_leftmnu', shlm, 365);
	chg_size();
}

$(function() {
	init_showhide_sidemenu();
});