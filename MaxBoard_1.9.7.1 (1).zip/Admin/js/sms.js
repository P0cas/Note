$(document).ready(function(){
	CheckStrLen();
	$("#msg").focus();
	get_sent_list();
});

$(document).on('click',".spc1 div",function() {
	var chars = $(this).html();
	insertAtCursor('msg', chars);
}).on('mouseover',".spc1 div",function() {
	$(this).css('background-color','#e5e5e5');
}).on('mouseout',".spc1 div",function() {
	$(this).css('background-color','');
});

var show_scroll = function(a,b) {
	if (b == 'on') {
		$(a).css('overflow-y','auto');
	}
	else if (b == 'off') {
		$(a).css('overflow-y','hidden');
	}
}

function send_smsx() {

	var msg = $('#msg').val(); //문자내용
	var fromn = $('#callback').val(); //발신번호
	var subject = $('#subject').val(); //제목
	var ton = $('#tolist').val(); //받는 사람 리스트

	if (msg == '') {
		alert ('문자내용을 입력해주세요.');
		$('#msg').focus();
	}
	else if (fromn == '') {
		alert ('발신번호를 선택해 주세요.');
		$('#callback').focus();
	}
	else if (ton == '') {
		alert ('수신자리스트를 입력해주세요. 작성형식에 맞춰 엑셀에서 작성하신후 복사해 붙여넣기를 권장합니다.');
	}
	else {

		var tmp = ton.split('\n');
		var tonum = 0;
		for (var t=0;t<tmp.length;t++) {
			//var tonum = tmp.length - 1;
			if (tmp[t] != '') {
				tonum++;
			}
		}

		var answer = confirm("'" + tonum + "'건의 문자를 발송하시겠습니까?");
		//alert (tmp.length);

		if (answer == true) {
			var url = "./ajax_send_msg.html";

			jQuery.ajaxSettings.traditional = true;
			$.post(
				url,
				{
					msg:msg,
					fromn:fromn,
					subject:subject,
					ton:ton,
					len_sms:$('#limit_sms').val(),
					len_lms:$('#limit_lms').val()
				},
				function (data) {//alert (data);
					//console.log(data);
					var tmp = data.split("|*|");
					if (tmp[1] == 'ok') {
						if (tmp[2] == tonum) {
							alert ("'" + tonum + "'건이 발송되었습니다.");
						}
						else {
							alert ("'" + tmp[2] + " / " + tonum + "'건이 발송되었습니다.");
						}
						get_sent_list();

						if (tmp[3] != 'x') {
							$('#remain_sms').html("<b>" + tmp[3] + "</b>건 (단문기준)");
							//console.log($('#remain_sms').html())
						}
					}
					else {
						alert ('오류로 인해 발송되지 않았습니다.');
					}
				}
			);
		}
	}
}

var save_temp = 'no';
function save_smsx() {

	if ($('#msg').val() == '') {
		alert ('문자내용을 입력해주세요.');
		return false;
	}
	else {
		var tsubject = prompt('저장할 문자서식의 제목을 입력해주세요.', '');

		if (tsubject != '' && tsubject != null) {
			var answer = confirm("해당 내용으로 문자서식을 저장하시겠습니까?");

			if (answer == true) {

				var url = "./ajax_save_msg.html";

				jQuery.ajaxSettings.traditional = true;
				$.post(
					url,
					{
						opt:'save',
						tsubject:tsubject,
						subject:$('#subject').val(),
						msg:$('#msg').val()
					},
					function (data) {
						console.log(data);
						var tmp = data.split("|*|");
						if (tmp[1] == 'saved') {
							alert ('저장되었습니다.');
							if (tmp[2] != '') {
								//$('.sms_opt1').prepend(tmp[2]);
								//$('.opt1_fake').after(tmp[2]);
								$('.opt1_cont').prepend(tmp[2]);
							}
						}
						else {
							alert ('오류로 인해 저장되지 않았습니다.');
						}
					}
				);
			}
		}
		else {
			alert ('문자서식의 제목을 입력해야 저장할 수 있습니다.');
		}
	}
}

function delSample(d) {

	var answer = confirm("해당 서식을 삭제하시겠습니까?");

	if (answer == true) {

		var url = "./ajax_save_msg.html";

		jQuery.ajaxSettings.traditional = true;
		$.post(
			url,
			{
				opt:'del',
				delnum:d
			},
			function (data) {
				//console.log(data);
				var tmp = data.split("|*|");
				if (tmp[1] == 'deleted') {
					alert ('삭제되었습니다.');
					$('#sp'+d).css('display','none');
				}
				else {
					alert ('오류로 인해 삭제되지 않았습니다.');
				}
			}
		);
	}
}

function input_check(check) {
	check_string = check.value;
	len = check_string.length;
	var char_ASCII = check_string.charCodeAt(check_string.length-1);

	if (len >= 1){
		//number
		if (char_ASCII >= 48 && char_ASCII <= 57 ){
			return true;
		}
		else {
			alert("숫자만 입력하실 수 있습니다.");
			check.value = '';
			return false;
		}
	}
}

function addfont(f){
	document.getElementById('msg').value += f;
	//var aa = a;
	//var bb = b;
	//CheckStrLen(bb);
	CheckStrLen();
}

function delsendnum(check){
    check.value = "";
}

function byte_check(str) {
	var len = 0;
	for (var i=0; i<str.length; i++) {
		var c = escape(str.charAt(i));
		if (c.length == 1) len++;
		else if (c.indexOf("%u") != -1) len += 2;
		else if (c.indexOf("%") != -1) len += c.length / 3;
	}
	return len;
}

var countcs = 0;
var subjectf, tailf;
var questnum = 0;
function CheckStrLen(b) {
	var type = document.getElementById('type').value;
	if (!b) {
		var b = parseInt(document.getElementById('limit_' + type).value);
	}
	var buffmsg = document.getElementById('msg').value;

	var ba = Math.floor(b/2);
	var msglen = 0;
	var msglen1 = 0;

	var len = msglen = byte_check($('#msg').val());
	var tmpstr = '';
	var tmpstr1 = '';
	var smslen = document.getElementById('limit_sms').value;

    if (len == 0) {
		$('#remain').html("0 / " + b + " Bytes");
	}
    else {
		if (msglen > b) {
			if (countcs == 0 && type == 'sms') {
				//countcs = 1;
				//var answer = confirm('총 ' + b + '바이트를 넘었습니다.\n장문(LMS)으로 전환하시겠습니까?');
				alert ('총 ' + b + '바이트를 넘어 장문(LMS)으로 전환됩니다');
				answer = true;

				if (answer == true) {
					document.getElementById('msg').value = buffmsg;
					document.getElementById('type').value = 'lms';

					$('.subject_field').css('display','block');
					$('.msg_field').css('height','200px');
					$('#msg').css('height','190px');

					document.getElementById('subjectf').value == 'block';
					CheckStrLen();
					return false;
				}
				else {
					if (document.getElementById('tailf').value == 'none') {
						$('.msg_field').css('height','249px');
						$('#msg').css('height','233px');
					}
					else {
						$('.msg_field').css('height','224px');
						$('#msg').css('height','208px');
					}
					$('.subject_field').css('display','none');
					document.getElementById('subjectf').value == 'none';
				}
				//alert('총 영문 ' + b + '자 한글 ' + ba + '자 기호 ' + ba + '개까지 보내실수 있습니다.');
			}
			else if (type == 'lms') {
				alert ('총 ' + b + '바이트를 넘어서, 더이상 입력하실 수 없습니다.');
			}
			//countcs = 0;

			for (m=0;m<msglen;m++) {
				var temp1 =  document.getElementById('msg').value.charAt(m);
				if (escape(temp1).length > 4 || temp1 == "'") msglen1 += 2;
				else msglen1++;

				if (msglen1 <= b) tmpstr1 +=  temp1;
				else break;
			}//alert (tmpstr1);*/
			document.getElementById('msg').value = tmpstr1;

			//break;
		}
		else {
			$('#remain').html(msglen + " / " + b + " Bytes");
		}
	}
	if (parseInt(msglen) <= parseInt(smslen)) {
		document.getElementById('type').value = 'sms';
		countcs=0;

		$('.subject_field').css('display','none');
		$('.msg_field').css('height','225px');
		$('#msg').css('height','215px');
		document.getElementById('subjectf').value == 'none';
		$('#remain').html(msglen + " / " + smslen + " Bytes");
	}

	chg_receiver_title();

	return false;
}

function chg_receiver_title() {
	//템플릿내용에서 변수 구분
	var msg = $('#msg').val(); //console.log(msg);
	var varx = new Array();
	var varFx = "작성형식: 1)전화번호"; //형식으로 보여줄 내용을 담을 변수선언

	//$tmp = explode("#{",$msg);
	var tmp = msg.split("#{"); //템플릿내용에 있는 변수시작 구분자로 파싱
	var x = 2;
	for (var a=1;a<tmp.length;a++) { //console.log(a);
		var tmp1 = tmp[a].split("}"); //각 변수구간을 다시 변수마침 구분자로 파싱해서 변수를 찾아낸다
		//console.log($.inArray(tmp1[0],varx));
		if ($.inArray(tmp1[0],varx) == -1) { //배열에 아직 넣지 않은 변수인 경우만 찾는다
			varFx += " " + x + ")" + tmp1[0]; //보여줄 형식으로 변수에 담는다
			varx.push(tmp1[0]);
			x++;
		}
	}

	$('.receiver_title').html(varFx);
}

function resetmsg() {
	document.getElementById('msg').value = '';
	document.getElementById('type').value = 'sms';
	countcs=0;

	$('.subject_field').css('display','none');
	$('.msg_field').css('height','225px');
	$('#msg').css('height','215px');
	$('.receiver_title').html('작성형식: 1)전화번호'); //작성형식
	//}

	document.getElementById('subjectf').value == 'none';
	CheckStrLen();
}

function openSpc(a,b) {

	if ($('#special_char_window').html() == '') {

		var spcA = new Array("▲", "▶", "▷", "▼", "▽", "◀", "◁", "◆", "◇", "◈", "□", "■", "○", "◎", "●", "◐", "◑", "★", "☆", "☎", "☏", "☜", "☞", "♀", "♂", "♠", "♡", "♣", "♤", "♥", "♧", "♨", "∩", "※", "™", "℡", "∑", "㉿", "ㆀ", "†", "▒", "3", "♩", "♪", "♬", "♭","σ", "～", "τ", "ω", "ψ", "μ", "Σ", "Ο", "Δ", "≠", "≤", "≥", "∞", "∴", "㉠", "㉡", "㉢", "㉣", "㉤", "㉥", "㉦", "㉧", "㉨", "㉩", "㉪", "㉫", "㉬", "㉭", "㉮", "㉯", "㉰", "㉱", "㉲", "㉳", "㉴", "㉵", "㉶", "㉷", "㉸", "㉹", "㉺", "㉻", "ⓐ", "ⓑ", "ⓒ", "ⓓ", "ⓔ", "ⓕ", "ⓖ", "ⓗ", "ⓘ", "ⓙ", "ⓚ", "ⓛ", "ⓜ", "ⓝ", "ⓞ", "ⓟ", "ⓠ", "ⓡ", "ⓢ", "ⓣ", "ⓤ", "ⓥ", "ⓦ", "ⓧ", "ⓨ", "ⓩ", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩", "⑪", "⑫", "⑬", "⑭", "⑮", "ⅰ", "ⅱ", "ⅲ", "ⅳ", "ⅴ", "ⅵ", "ⅶ", "ⅷ", "ⅸ", "ⅹ", "Ⅰ", "Ⅱ", "Ⅲ", "Ⅳ", "Ⅴ", "Ⅵ", "Ⅶ", "Ⅷ", "Ⅸ", "Ⅹ", "♂", "♀", "∠", "⊥", "⌒", "∇", "━", "┃", "┏", "┓", "┗", "┛", "┣", "┫", "┳", "┻", "╋", "─", "│", "┌", "┐", "└", "┘", "├", "┤", "┬", "┴", "┼", "☆(~.^)/", "^.^", "s(^o^)s", "&(☎☎)&", "(*^.^)♂", "b^^d", "(^.^)V", "(o^^)o", "o(^^o)", "^o^~~♬", "_(≥∇≤)ノ", "q⊙.⊙p", "=◑.◐=", "^Δ^", "*^^*", "S(*^___^*)S", "＼(*^▽^*)ノ", "^L^", "^ε^", "^_^", "(ノ^O^)ノ", "^0^", "^.~");
		var spcs = "<div class='spc_back'>";
		spcs += "<div class='spc'><div class='spc_title'>특수문자삽입</div><img alt='' src='<?=$site_url?>/images/delete1.gif' style='cursor:pointer' onclick=\"$('#special_char_window').slideUp(200).html('');\"></div>";
		spcs += "<div class='spc1'>";

		  for (var y=0;y<spcA.length;y++) {
			  spcs += "<div>" + spcA[y] + "</div>";
		  }

		spcs += "</div>";
		spcs += "</div>";

		$('#special_char_window').html(spcs).slideDown();

	}
	else $('#special_char_window').slideUp(200).html('');
}

function insertAtCursor(id, myValue) {
	var myField = document.getElementById(id);
    //IE support
    if (document.selection) {
        myField.focus();
        sel = document.selection.createRange();
        sel.text = myValue;
    }
    // Microsoft Edge
    else if(window.navigator.userAgent.indexOf("Edge") > -1) {
      var startPos = myField.selectionStart;
      var endPos = myField.selectionEnd;

      myField.value = myField.value.substring(0, startPos)+ myValue
             + myField.value.substring(endPos, myField.value.length);

      var pos = startPos + myValue.length;
      myField.focus();
      myField.setSelectionRange(pos, pos);
    }
    //MOZILLA and others
    else if (myField.selectionStart || myField.selectionStart == '0') {
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        myField.value = myField.value.substring(0, startPos)
            + myValue
            + myField.value.substring(endPos, myField.value.length);
    } else {
        myField.value += myValue;
    }

	CheckStrLen();
}

function get_sent_list(offset) {
	var url = "./ajax_get_sent_list.html";

	jQuery.ajaxSettings.traditional = true;
	$.post(
		url,
		{
			offset:offset
		},
		function (data) {//alert (data);
			//console.log(data);
			var tmp = data.split("|*|");
			if (tmp[1] == 'ok') {
				$('.optx_cont').html(tmp[2]);
			}
			else if (tmp[1] == 'noresult') {
				$('.optx_cont').html("<div class='pre_opt'>발송한 이력이 존재하지 않습니다.</div>");
			}
			else if (tmp[1] == 'needlogin') {
				alert ('세션이 만료되었습니다. 다시 로그인해주세요.');
				location.href='index.html';
			}
			else {
				alert ('오류로 인해 발송이력을 가져올 수 없습니다.');
			}
		}
	);
}

function topage(offset,tovar) {
	get_sent_list(offset);
}