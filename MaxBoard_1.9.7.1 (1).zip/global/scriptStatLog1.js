var StatLogPassurl = direct + "/global/ajaxStatLogPass1.html";
var pagem = '';
var chkslp;
var next_n = '0';
var now_n = '0';
var next_nb;

function StatLogPassChk1(pagex,prev,prevb) { //alert ('c');
	if (!prev) {
		clearInterval(chkslp);
		clearTimeout(chkslp);
	}

	if (pagex) {
		var pg = pagex;
		pagem = pagex;
	}
	else var pg = "";

	if (prev) {
		var pv = prev;
		var pvb = prevb;
	}
	else {
		var pv = "";
		var pvb = "";
	}

	//console.log(pv);

	//var pointD = document.getElementById('pointDate').value; //alert (pointD);
	var pointD = $('#pointDate').val(); //alert (pointD);

	jQuery.ajaxSettings.traditional = true;
	$.post(
		StatLogPassurl,
		{
			a:pointD,
			pg:pg,
			pv:pv,
			pvb:pvb
		},
		function (data) {//console.log(data);
			var res = data.split("tryloginagain"); //alert (res.length);
			if (res.length == 2) {
				alert ("세션이 종료되었습니다. 다시 로그인해 주십시오.");
				location.reload();
			}
			else if (data != '') {
				var tmp = data.split("|*|");
				//document.getElementById('titleTable').innerHTML = tmp[0];
				$('#titleTable').html(tmp[0]);
				//if (tmp[1] != '') document.getElementById('ipTable').innerHTML = tmp[1] + document.getElementById('ipTable').innerHTML;
				if (tmp[1] != '') $('#ipTable').prepend(tmp[1]);
				//if (tmp[2] != '') document.getElementById('logTable').innerHTML = tmp[2] + document.getElementById('logTable').innerHTML;
				if (tmp[2] != '') {
					$('#logTable').prepend(tmp[2]);
					$('#logTable div').slideDown(300);
					//$('#logTable div').fadeIn(300);
					if (tmp[4] != '') {
						next_n = tmp[4];
						next_nb = tmp[5];
					}
				}
				if (tmp[3] != '') {
					$('#logTable').append(tmp[3]);
					//$('#logTable div').slideDown(300);
					$('#logTable div').css('display','block');
					next_n = tmp[4];
					next_nb = tmp[5];
				}
				if (pv == '') chkslp = setTimeout("StatLogPassChk1(pagem);",50000);
			}
		}
	);
}

$(function() {
	$('#logTable').scroll(function(){
		var y = $('#logTable').scrollTop() + $('#logTable').innerHeight() + 300;
		//console.log(y + ' , ' + parseInt($('#logTable').height()) + ' , ' + parseInt($('#logTable').prop('scrollHeight')) + ' , ' + now_n + ' , ' + next_n);
		if (parseInt($('#logTable').prop('scrollHeight')) <= parseInt(y) && now_n != next_n){
			now_n = next_n;
			//console.log(now_n + ' , ' + next_n + ' , '  + next_nb);
			StatLogPassChk1(pagem, next_n, next_nb);
		}
	});
});