function quick_menu_slide(){

	var viewportWidth = window.innerWidth;
    var viewportHeight = window.innerHeight;

	var scrollwidth = Math.max(document.documentElement.scrollLeft,$(document.body).scrollLeft());

    var b_width = $(document.body).width() + scrollwidth; //페이지 전체크기
    var d_width = $("#head_menu_layout").width(); //본문 전체 크기임
    var t_height = Math.max(document.documentElement.scrollTop,$(document.body).scrollTop()); //상단 높이


    //var width = (b_width - d_width) <= 0 ? 920 : b_width/2 + 440; //왼쪽으로 부터 얼마를 떨어뜨려야할지.
    //var height = t_height + 118; //상단부터 띄워야 하는 높이

	var menuwidth = 60; // 따라다니는 이미지의 가로크기
	//var menuheight = 90; // 따라다니는 이미지의 세로크기
	if (menuheight == '') menuheight = 90;

    var width = (b_width - menuwidth - 30) <= 0 ? 1 : b_width - menuwidth - 30;
	var height = (t_height + document.documentElement.clientHeight - menuheight - 30) <= 0 ? 1: t_height + document.documentElement.clientHeight - menuheight - 30;
	//var height = t_height + 118;

	// width 나 height 값이 음수가 나오면 오류가 나므로 계산이 항상 양수가 나오게 해야 한다.

    $("#quick_menu_div").css({top:height, left:width, display:'block'});
}

$(window).load(quick_menu_slide).resize(quick_menu_slide).scroll(quick_menu_slide);
//->메서드 체인. 로딩, 창 리사이즈, 페이지 스크롤 될때 불러들임.