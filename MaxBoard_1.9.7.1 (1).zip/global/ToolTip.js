/* ########## 이용방법 ###########
##  저작자 : 이준규(maxhellovan@gmail.com)
##  제작일 : 2009년 08월 27일
##  수정일 : 2021년 04월 09일
##  ver 1.7.0b
*/

var Xwidth = 150;
var Fwidth;
var Xfixed;
var Yfixed;
var Xtmp;
var Ytmp;
var MoveC ="ok";
var toolTp = 1;
var gtlX;

var nv = (document.layers);
var ex = (document.all);
if (nv) {
   var TMov = document.tooltipMov;
   var TFix = document.tooltipFix;
}
else if (ex) {
   //var TMov = tooltipMov.style;
   //var TFix = tooltipFix.style;
   var TMov = document.getElementById("tooltipMov").style;
   var TFix = document.getElementById("tooltipFix").style;
}
else {
	document.addEventListener('mousemove',SaveMouseEventT,false);
	var TMov = document.getElementById("tooltipMov").style;
	var TFix = document.getElementById("tooltipFix").style;
}

function SaveMouseEventT(e) {
    MouseEventValue = e;
}

//하단에서 실행
//document.onmousedown = get_mouse;
//document.onmouseup = get_mouse;
//if (nv) document.captureEvents(Event.MOUSEMOVE);
//document.onmousemove = get_mouse;

function pop(framec,title,titlec,msg,msgc,bakc) {
    var content ="<table width='400' style='border:solid 1px #393939' cellpadding='2' cellspacing='0' bgcolor='" +framec+ "'><tr><td><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td align='left' style='font-size:12px;color:" + titlec + ";font-weight:bold;padding:5px;'>" +title+ "</td></tr></table><table width='100%' border='0' cellpadding='2' cellspacing='0' bgcolor='"+bakc+"'><tr><td align='left' style='font-size:12px;color:" +msgc+ "'>"+decodeURIComponent(msg)+"</td></tr></table></td></tr></table>";

    Xwidth = 400;

    visibilityX(content);
}

function popx(framec,title,titlec,msg,msgc,bakc,x) {
    if (x == '0' || x == 0 || x == '') var width = "width:0;";
    else var width = "width:" + x + "px;";
    var content ="<div style='border:solid 1px #393939;background-color:" + bakc + ";'><div style='text-align:left;padding:5px;background-color:" + framec + ";color:" + titlec + ";font-weight:bold;'>" + title + "</div><div style='text-align:left;padding:5px;line-height:16px;background-color:" + bakc + ";font-size:12px;color:" +msgc+ ";" + width + ";'>"+decodeURIComponent(msg)+"</div></div>";

    Xwidth = x;

    visibilityX(content);
}

function popimgx(framec,framepx,img,x) {
    if (framepx == '0' || framepx == 0 || framepx == '') var border = "";
    else var border = "border:" + framepx + "px solid " + framec + ";";
    var content ="<div style='background-color:#ffffff;" + border  + "'><img alt='' src='"+img+"'  width='"+x+"' /></div>";

    Xwidth = x;

    visibilityX(content);
}

function popimgidx(framec,framepx,img,x,imgid) {
    if (framepx == '0' || framepx == 0 || framepx == '') var border = "";
    else var border = "border:" + framepx + "px solid " + framec + ";";
    var content ="<div style='background-color:#ffffff;" + border  + "'><img alt='' src='"+img+"' id='"+imgid+"'  width='"+x+"' /></div>";

    Xwidth = x;

    visibilityX(content);
}

function popT(msg,msgc,msgs,bakc,framec,framepx,x) {
    if (framepx == '0' || framepx == 0 || framepx == '') var border = "";
    else var border = "border:" + framepx + "px solid " + framec + ";";
    if (x == '0' || x == 0 || x == '') var width = "width:0;";
    else var width = "width:" + x + "px;";
    var content ="<div style='text-align:left;padding:5px;background-color:" + bakc + ";font-size:" + msgs + "px;color:" +msgc+ ";" + border  + width + "'>"+decodeURIComponent(msg)+"</div>";

    Xwidth = x;

    visibilityX(content);
}

function popTr(msg,msgc,msgs,bakc,framec,framepx,x,padding,radius) {
    if (framepx == '0' || framepx == 0 || framepx == '') var border = "";
    else var border = "border:" + framepx + "px solid " + framec + ";";
    if (x == '0' || x == 0 || x == '') var width = "width:0;";
    else var width = "width:" + x + "px;";
    var content ="<div style='text-align:left;padding:"+padding+"px;background-color:" + bakc + ";border-radius:" + radius + "px;font-size:" + msgs + "px;color:" +msgc+ ";" + border  + width + "'>"+decodeURIComponent(msg)+"</div>";

    Xwidth = x;

    visibilityX(content);
}

function visibilityX(content){
	TMov.zIndex = zidx++;
    if (nv) {
        TMov.document.write(content);
        TMov.document.close();
        TMov.display = "inline-block";
    }
    else if (ex) {
        document.getElementById("tooltipMov").innerHTML = content;
        TMov.display = "inline-block";
    }
    else {
        document.getElementById('tooltipMov').innerHTML = content;
        TMov.display = "inline-block";
    }
}

function get_mouse(e) {

	$('.drag').mouseover(function() {
		document.onmousedown = mdown;
		document.onmouseup = mup;
		document.onmousemove = moveimg;
	});


	if (nv) {
		var x = e.pageX;
		var y = e.pageY;
	}
	else if (ex){
		/*
		var x = event.x+document.documentElement.scrollLeft;
		if( navigator.appVersion.indexOf("MSIE 6") > -1 && document.body.scrollTop == ''){ //IE6
		var y = event.y+document.documentElement.scrollTop;
		}
		else if (navigator.appVersion.indexOf("MSIE 7") > -1 && document.body.scrollTop == ''){ //IE7
		var y = event.y+document.documentElement.scrollTop;
		}
		else if (navigator.appVersion.indexOf("MSIE 8") > -1){ //IE8
		var y = event.y + document.body.scrollTop;
		}
		else { // 그외
		y = event.y+document.documentElement.scrollTop;
		}
		*/
		if (document.body.scrollTop != '') {
			var y = event.y+document.body.scrollTop;
		}
		else if (navigator.appVersion.indexOf("MSIE 7") > -1 || navigator.appVersion.indexOf("MSIE 8") > -1) {
			if (location.href.indexOf("Admin") > -1) var y = event.y+document.documentElement.scrollTop;
			else var y = event.y;
		}
		else {
			var y = e.clientY+document.documentElement.scrollTop;
		}

		if (document.body.scrollLeft != '') {
			var x = event.x+document.body.scrollLeft;
		}
		else if (navigator.appVersion.indexOf("MSIE 7") > -1 || navigator.appVersion.indexOf("MSIE 8") > -1) {
			var x = event.x+document.documentElement.scrollLeft;
		}
		else {
			var x = e.clientX+document.documentElement.scrollLeft;
		}
	}
	else if (e.clientX || e.clientY) {
		if (document.body.scrollTop != '') var y = e.clientY+document.body.scrollTop; //크롬
		else var y = e.clientY+document.documentElement.scrollTop; // 파폭

		if (document.body.scrollLeft != '') var x = e.clientX+document.body.scrollLeft; //크롬
		else var x = e.clientX+document.documentElement.scrollLeft; // 파폭
	}

	if (ex) {
		if (window.document.body.clientWidth) {
			var w = window.document.body.clientWidth;
			var h = window.document.body.clientHeight;
		}
		else {
			var w = window.document.documentElement.clientWidth;
			var h = window.document.documentElement.clientHeight;
		}
	}
	else {
		var w = window.document.documentElement.clientWidth;
		var h = window.document.documentElement.clientHeight;
	}

	var TMovX = x - 100;
	var TMovY = y + 20;

	var tw = w - parseInt(Xwidth);

	if (x > tw) {
		Fwidth = x - tw + 10;
		if (document.body.scrollLeft != '') tw = x - Fwidth + document.body.scrollLeft;
		else tw = x - Fwidth + document.documentElement.scrollLeft;

		gtlX = x - tw + 15;
	}
	else {
		Fwidth = 10;
		gtlX = 15;
	}

	if (TMovX > tw - 15) TMovX = tw - 15;
	else if (TMovX < 15) TMovX = 15;

	TMov.left = TMovX + 'px';
	TMov.top = TMovY + 'px';

	if (x > tw) Xtmp = tw -10;
	else Xtmp = x -10;
	Ytmp = y + 10;

	//(20-08-07) 상대경로인경우 보정해준다
	//console.log(e.target,$(e.target).offset().top,$(e.target).position().top);
	/*
	$(e.target).css('position','relative');
	console.log(tw, $(e.target).position().left)
	if ($(e.target).position().left > tw) Xtmp = tw -10;
	else Xtmp = $(e.target).position().left + 200;
	Ytmp = $(e.target).position().top + $(e.target).height() + 10;

	Xtmp = $(e.target).position().left;
	*/

}

function off() {
    TMov.display = "none";
}

// JavaScript Calendar

var cal_frm = "";
var cal_fld = "";
var cal_idx = "";
var cal_id = "";
var cal_d_year = ""; //default로 넘어온 년도를 담을 변수
var cal_d_month = "";//default로 넘어온 월을 담을 변수
var cal_d_day = "";  //default로 넘어온 날짜를 담을 변수
var tmpImg = new Image
var arrImg = new Array();
var direct = document.getElementById('direct').value;
tmpImg.src = direct + "/images/arrow_prev.gif";arrImg[0] =tmpImg.src;
tmpImg.src = direct + "/images/arrow_next.gif";arrImg[1] =tmpImg.src;
var prev_img = "<img alt='' src='"+arrImg[0]+"' border='0' style='text-align:center;vertical-align:middle;' />"
var next_img = "<img alt='' src='"+arrImg[1]+"' border='0' style='text-align:center;vertical-align:middle;' />"

//var nv = (document.layers);
//var ex = (document.all);

//if (nv) document.captureEvents(Event.MOUSEMOVE);
//document.onmousemove = get_mouseC;

function setObj(formName,fieldName,index,defaultD,e) {
	//폼베이스 전용
	cal_frm = formName;
	cal_fld = fieldName;
	cal_idx = index || "";

	//ID베이스 전용 (초기화)
	cal_id = "";

	popEnterBa();

	MoveC = 'no';
	cal_d_year = ""; //(초기화)
	cal_d_month = ""; //(초기화)
	cal_d_day = ""; //(초기화)

	if (defaultD) {
		var tmpym = defaultD.split("-");
		if (tmpym[2] != '') {
			cal_d_year = tmpym[0];
			cal_d_month = tmpym[1];
			cal_d_day = tmpym[2];
			cal(tmpym[0],tmpym[1],tmpym[2]);
		}
		else cal(tmpym[0],tmpym[1]);
	}
	else {
		cal();
	}
}
/*
function setObj1(formName,fieldName,index,defaultD,e) {
	//폼베이스 전용
	cal_frm = formName;
	cal_fld = fieldName;
	cal_idx = index || "";

	//ID베이스 전용 (초기화)
	cal_id = "";

	var tmpym = defaultD.split("-");

	popEnterBa();

	MoveC = 'no';

	cal(tmpym[0],tmpym[1]);
}
*/
function setObjID(idx,defaultD,e) {
	if (document.getElementById(idx)) {
		//폼베이스 전용 (초기화)
		cal_frm = "";
		cal_fld = "";
		cal_idx = "";

		//ID베이스 전용
		cal_id = idx;

		popEnterBa();

		MoveC = 'no';
		cal_d_year = ""; //(초기화)
		cal_d_month = ""; //(초기화)
		cal_d_day = ""; //(초기화)

		if (defaultD) {
			var tmpym = defaultD.split("-");
			if (tmpym[2] != '') {
				cal_d_year = tmpym[0];
				cal_d_month = tmpym[1];
				cal_d_day = tmpym[2];
				cal(tmpym[0],tmpym[1],tmpym[2]);
			}
			else cal(tmpym[0],tmpym[1]);
		}
		else {
			cal();
		}
	}
}

function setDate(y, m, d) {
	m = (m.toString().length==1)? "0"+m : m;
	d = (d.toString().length==1)? "0"+d : d;
	var date = y + "-" + m + "-" + d;
	if (cal_frm != '') {
		var ele = eval("document."+cal_frm+"."+cal_fld)
		var cnt = ele.length;
	}
	else {
		var cnt = 'id';
	}
	if (cnt == 'id') {
		document.getElementById(cal_id).value = date;
	}
	else if(typeof(cnt)=="undefined" || cnt < 2){
	    ele.value = date;
	}
	else{
	    for(var i =0;i<cnt;i++)  {
		    var tmpEle = eval("document."+cal_frm+"."+cal_fld);
		    if(tmpEle[i].cal_idx==cal_idx) {
		        tmpEle[i].value = date;
			}
		}
	}

	offT();
}

function YMselchg(y,m) {
	var ysel = '';
	var msel = '';
	if (y == 'ysel') ysel = $('#Ysel').val();
	else ysel = y;
	if (m == 'msel') msel = $('#Msel').val();
	else msel = m;
	//console.log(ysel,msel)
    cal(ysel,msel,null,'notMove');
}

function cal(year, month, day, move) { console.log(year,month)
	if (move) movex = move;
	else movex = '';
	var date = new Date();
	var nowYear = date.getFullYear();
	nowYear = (nowYear < 1000) ? nowYear + 1900 : nowYear;
	var nowMonth = date.getMonth()+1;
	var curYear = year || nowYear;
	var curMonth = month || nowMonth;
	curMonth = parseInt(curMonth);
	var yearsel = "<select id='Ysel' onchange=\"YMselchg(this.value,'msel')\">";
	for (var ys=nowYear+50;ys>=nowYear-50;ys--){
		if (curYear == ys) var sely = " selected";
		else sely = "";
		yearsel += "<option value='"+ys+"'"+sely+">"+ys+"</option>";
	}
	yearsel += "</select>";
	var monthsel = "<select id='Msel' onchange=\"YMselchg('ysel',this.value)\">";
	for (var ms=1;ms<=12;ms++){
		if (parseInt(curMonth) == ms) var selm = " selected";
		else selm = "";
		monthsel += "<option value='"+ms+"'"+selm+">"+ms+"</option>";
	}
	monthsel += "</select>";
	var curDate = date.getDate();
	var curDay = day || curDate;
	var february = ((0 == curYear % 4) && (0 != (curYear % 100))) ||
		 (0 == curYear % 400) ? 29 : 28;
	var arrMonth = new Array("1","2","3","4","5","6","7","8","9","10","11","12");
	var arrLastDate = new Array(31, february, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
	var arrDay = new Array("S", "M", "T", "W", "T", "F", "S");
	/*
	var link_year_prev = "<font style='cursor:pointer' onClick='cal("+(parseInt(curYear)-1)+","+curMonth+");'>";
	var link_year_next = "<font style='cursor:pointer' onClick='cal("+(parseInt(curYear)+1)+","+curMonth+");'>";
	var prev_year = (parseInt(curMonth) == 1)? parseInt(curYear) - 1:curYear;
	var prev_month = (parseInt(curMonth) == 1)? 12 : parseInt(curMonth) - 1;
	var next_year = (curMonth == 12)? parseInt(curYear)+1:curYear;
	var next_month = (curMonth == 12)? 1 : parseInt(curMonth) + 1;
	var link_month_prev = "<font style='cursor:pointer' onClick='cal("+prev_year+","+prev_month+")'>";
	var link_month_next = "<font style='cursor:pointer' onClick='cal("+next_year+","+next_month+")'>";
	*/
	var arrDate = new Array("&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;")
	var tmpDate = new Date(curYear, curMonth-1, 1)
	var startPos = tmpDate.getDay();

	var j = 1;
	for(var i = startPos; i<arrLastDate[curMonth-1]+startPos; i++) {
		if (curYear == cal_d_year && curMonth == cal_d_month && j == cal_d_day) var bg = "background-color:#5ea8ec;color:#ffffff";
		else var bg = "";
	    if (curYear == nowYear && curMonth == nowMonth && j == curDate) arrDate[i] = "<font onClick='setDate("+curYear+","+curMonth+",\""+j+"\")' style='cursor:pointer;font-size:12px;padding:2px;"+bg+"' color='#009950'><b><u>"+j+"</u></b></font>";
	    else arrDate[i] = "<font onClick='setDate("+curYear+","+curMonth+",\""+j+"\")' style='cursor:pointer;padding:2px;"+bg+"'>"+j+"</font>";
	    j++;
	}

	var cont  = "<div style='width:175px;border:1px solid #808080;background-color:#ffffff;padding:20px !important;'>";
	cont += "<table border='0' cellpadding='0' cellspacing='0' style='vertical-align:middle;width:100%;background-color:#ffffff;'><tr><td style='vertical-align:middle; width:158px; padding:0; border:0; text-align:center;'>";
	/*
	cont += link_year_prev+prev_img+"</font></td><td width='55' align='center' style='vertical-align:middle;'><b>"+curYear+"년</b></td><td width='11' style='vertical-align:middle;'>"+link_year_next+next_img+"</font></td><td width='5' style='vertical-align:middle;'></td><td width='11'>";
	cont += link_month_prev+prev_img+"</font></td><td width='35' align='center' style='vertical-align:middle;'><b>"+curMonth+"월</b></td><td width='11' style='vertical-align:middle;'>"+link_month_next+next_img+"</font>";*/
	cont += yearsel + "년 " + monthsel + "월";
	cont += "</td><td style='width:20px !important; text-align:right; vertical-align:middle; padding:0; border:0;'><font style='cursor:pointer' onClick='offT()'><img alt='' src='"+direct+"/images/delete1.gif' style='width:13px !important;' border='0' /></font>"
	cont += "</td></tr></table>"
	cont += "</td></tr>";

	cont += "<tr><td align='center'>"

	cont += "<table border='0' width='' cellpadding='1' cellspacing='0' bgcolor='#ffffff'>"
	cont += "<tr height='25' align='center'>"

	cont += "<td style='width:25px; padding:0; border:0; text-align:center;'><strong><font color='#E43030'>"+arrDay[0]+"</font></strong></td>"
	cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDay[1]+"</td>"
	cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDay[2]+"</td>"
	cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDay[3]+"</td>"
	cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDay[4]+"</td>"
	cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDay[5]+"</td>"
	cont += "<td style='width:25px; padding:0; border:0; text-align:center;'><strong><font color='#0071bc'>"+arrDay[6]+"</font></strong></td>"

	for(var i =0; i<arrDate.length;i+=7) {
	    if(i!=35 || arrDate[35]!="&nbsp;") {
			cont += "<tr style='height:25px' align='center'>";
			cont += "<td style='width:25px; padding:0; border:0; text-align:center;'><font color='#E43030'>"+arrDate[i]  +"</font></td>";
			cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDate[i+1]+"</td>";
			cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDate[i+2]+"</td>";
			cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDate[i+3]+"</td>";
			cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDate[i+4]+"</td>";
			cont += "<td style='width:25px; padding:0; border:0; text-align:center;'>"+arrDate[i+5]+"</td>";
			cont += "<td style='width:25px; padding:0; border:0; text-align:center;'><font color='#0071bc'>"+arrDate[i+6]+"</font></td>";
			cont += "</tr>";
		}
	}
	cont += "</table>";
	cont += "</div>";

	Xwidth = 215;

	visibilityXT(cont, movex);
}

function popEnterBa(){
	Xfixed = "";
	Yfixed = "";
}

function popEnterB(a,b,c,d) {
	//a:제목, b:내용, c:가로길이, d:세로의 최대길이(max-height)
	MoveC = 'no';

	var width = c;
	var twidth = parseInt(width) + 6;
	Xwidth = twidth;
	var fwidth = parseInt(Fwidth);
	if (fwidth > width) var fwidth = width - 15;
	var rwidth = width - fwidth - 15;

	if (d) var max_height = d;
	else var max_height = c; //세로 최대길이를 지정하지 않으면 가로폭과 동일하게 지정
	//alert(Xwidth.value + ", " + Fwidth.value);

	var content ="<div style='border:3px solid #7cb2cc;overflow-y:auto;max-height:"+max_height+"px;width:"+twidth+"px;margin:15px 0 0 0; padding:5px; background-color:#ffffff;'>";
		content +="<div style='font-size:16px;color:#000000;font-weight:bold;padding:5px 0 10px 10px;'>"+a+"</div>";
		content +="<div>"+b+"</div>";
		content +="<div style='text-align:right;'>&nbsp;<button type='button' onclick='offT()' style='cursor:pointer;padding:3px 10px;border-radius:3px;'>닫기</button>&nbsp;&nbsp;&nbsp;</div>";
	content +="</div>";


	visibilityXT(content);

}

function popEnterB1(a,b,c,d,e,f,g) {
	//a:풍선창테두리색, b:풍선창테두리두께, c:배경색, d:내용, e:가로사이즈, f:1:닫기버튼/0:버튼없음, g:세로의 최대길이(max-height)
	MoveC = 'no';

	var width = e;
	var twidth = parseInt(width) + (parseInt(b) * 2);
	Xwidth = twidth;
	var fwidth = parseInt(Fwidth);
	if (fwidth > width) var fwidth = width - 15;
	var rwidth = width - fwidth - 15;

	if (g) var max_height = g;
	else var max_height = e; //세로 최대길이를 지정하지 않으면 가로폭과 동일하게 지정

	//alert(Xwidth + ", " + Fwidth + ", " + Xfixed + ", " + Yfixed + ", " + MoveC);
	var content = "<div style='margin:14px 0 0 0;width:"+width+"px;border:"+b+"px solid "+a+";background-color:"+c+";padding:5px 5px 10px 5px;overflow-y:auto;max-height:"+max_height+"px;'>";

	if (f == '1') content += "<div style='text-align:right;margin:0 3px;line-height:7px;padding:5px;'><font onclick='offT()' style='cursor:pointer'>x</font></div>";

	content += d + "</div>";

	visibilityXT(content);

}

function popEnterB1r(t,a,b,c,d,e,f,g,h) {
	//t:풍선창 타이틀, a:풍선창테두리색, b:풍선창테두리두께, c:배경색, d:내용, e:가로사이즈, f:1:닫기버튼/0:버튼없음, g:테두리곡선반경, h:세로의 최대길이(max-height)
	MoveC = 'no';

	var width = e;
	var twidth = parseInt(width) + (parseInt(b) * 2);
	Xwidth = twidth;
	var fwidth = parseInt(Fwidth);
	if (fwidth > width) var fwidth = width - 15;
	var rwidth = width - fwidth - 15;
	//alert(Xwidth + ", " + Fwidth + ", " + Xfixed + ", " + Yfixed + ", " + MoveC);

	if (h) var max_height = h;
	else var max_height = e; //세로 최대길이를 지정하지 않으면 가로폭과 동일하게 지정

	if (f == '1') var pdd = "5px 5px 20px 5px";
	else var pdd = "5px 5px 10px 5px";

	var content = "<div style='margin:14px 0 0 0;width:"+width+"px;border:"+b+"px solid "+a+";background-color:"+c+";padding:" + pdd + ";border-radius:"+g+"px;overflow-y:auto;max-height:"+max_height+"px;'>";

	if (f == '1') content += "<div style='text-align:right;margin:0 3px;line-height:7px;padding:5px;'><font onclick='offT()' style='cursor:pointer'>X</font></div>";

	if (t) content += "<div style='font-size:16px;color:#000000;font-weight:bold;padding:5px 0 10px 10px;'>"+t+"</div>";

	content += d + "</div>";

	visibilityXT(content);

}

function popEnterCr(t,a,b,c,d,e,f,g,h) {
	//t:풍선창 타이틀, a:풍선창테두리색, b:풍선창테두리두께, c:배경색, d:내용, e:가로사이즈, f:1:닫기버튼/0:버튼없음, g:테두리곡선반경, h:세로의 최대길이(max-height)
	MoveC = 'no';

	var width = e;
	var twidth = parseInt(width) + (parseInt(b) * 2);
	Xwidth = twidth;
	var fwidth = parseInt(Fwidth);
	if (fwidth > width) var fwidth = width - 15;
	var rwidth = width - fwidth - 15;
	//alert(Xwidth + ", " + Fwidth + ", " + Xfixed + ", " + Yfixed + ", " + MoveC);

	if (h) var max_height = h;
	else var max_height = e; //세로 최대길이를 지정하지 않으면 가로폭과 동일하게 지정

	if (f == '1') var pdd = "5px 5px 10px 5px";
	else var pdd = "5px 5px 10px 5px";

	var gtlt = -6 + (parseInt(b) * 2);

	var content = "<div class='gtL_tri_line' style='position:absolute; top:-6px; left:"+gtlX+"px; display:inline-block; width:0; height:0; border-style:solid; border-width:15px 10px; border-color:transparent transparent "+a+" transparent; z-index:101;'></div><div class='gtL_tri' style='position:absolute; top:"+gtlt+"px; left:"+gtlX+"px; display:inline-block; width:0; height:0; border-style:solid; border-width:15px 10px; border-color:transparent transparent #ffffff transparent; z-index:102;'></div><div style='margin:23px 0 0 0;width:"+width+"px;border:"+b+"px solid "+a+";background-color:"+c+";padding:" + pdd + ";border-radius:"+g+"px;overflow-y:hidden;max-height:"+max_height+"px;box-shadow:0 2px 2px 1px #9e9e9e;'>";

	if (f == '1') content += "<div style='position:absolute;top:35px; right:10px; text-align:right;margin:0 3px;line-height:7px;padding:5px; width:20px;'><font onclick='offT()' style='cursor:pointer'>X</font></div>";

	if (t) content += "<div style='font-size:16px;color:#000000;font-weight:bold;padding:5px 0 10px 10px;'>"+t+"</div>";

	var inner_height = max_height - 60;

	content += "<div style='width:calc(100% - 20px);max-height:"+inner_height+"px;margin:0 4px; padding:10px 5px; border:1px solid #cacaca; overflow-y:auto; overflow-x:hidden; line-height:20px;'>" + d + "</div></div>";

	visibilityXT(content);

}

function visibilityXT(content,move) {//console.log(TFix.left + ' : ' + Xtmp);
    if (nv) {
	    TFix.document.write(content);
	    TFix.document.close();
	    //TFix.display = "inline-block";
    }
    else if (ex) {
	    document.all("tooltipFix").innerHTML = content;
	    //TFix.display = "inline-block";
    }
    else {
	    document.getElementById('tooltipFix').innerHTML = content;
	    //TFix.display = "inline-block";
    }
	if (!move || move != 'notMove') {
		TFix.left = parseInt(Xtmp) + 'px';
		TFix.top = parseInt(Ytmp) + 'px';
	}
    //$('#tooltipFix').slideDown(300);
	//$('#tooltipFix').fadeIn(300);

	if ($('#'+cal_id).length > 0) {
		var contTTF = "";
		contTTF += "<font id='tooltipFixNew' style='position:relative; z-index:11001; width:0; height:0; display:none'>";
		//contTTF +=     "<div style='position:absolute; top:" + ($('#'+cal_id).height() + 20)  + "px; left:-" + $('#'+cal_id).position().left + "px;'>" + content + "</div>";
		contTTF +=     "<div style='position:absolute; top:" + ($('#'+cal_id).height() + 20)  + "px; left:0;'>" + content + "</div>";
		contTTF += "</font>";
		$('#tooltipFixNew').remove();
		$('#'+cal_id).before(contTTF);
		$('#tooltipFixNew').fadeIn(300);
	}
	else {
		$('#tooltipFix').slideDown(300);
	}
};

function offT() {
	TFix.display = "none";
	$('#tooltipFixNew').remove();
}

function colorSel() {
	addary = new Array(); //red
	addary[0] = new Array(0,1,0); //red green
	addary[1] = new Array(-1,0,0); //green
	addary[2] = new Array(0,0,1); //green blue
	addary[3] = new Array(0,-1,0); //blue
	addary[4] = new Array(1,0,0); //red blue
	addary[5] = new Array(0,0,-1); //red
	addary[6] = new Array(255,1,1);
	clrary = new Array(360);

	for(i = 0; i < 6; i++) {
	    for(j = 0; j < 60; j++) {
		    clrary[60 * i + j] = new Array(3);
		    for(k = 0; k < 3; k++) {
			    clrary[60 * i + j][k] = addary[6][k];
			    addary[6][k] += (addary[i][k] * 4);
		    }
	    }
	}
}

function capture() {

    colorSel();

    if(document.layers) {
	    layobj = document.layers['wheel'];
	    layobj.document.captureEvents(Event.MOUSEMOVE);
	    layobj.document.onmousemove = moved;
    }
    else if (document.all){
	    layobj = document.all["wheel"];
	    layobj.onmousemove = moved;
    }
    else {
	    document.addEventListener('mousemove',moved,false);
	    document.getElementById('wheel').sourceHTML = document.getElementById('wheel').innerHTML;
    }
}

function moved(e) {
    if (document.layers) {
	    var y = 4 * (e.layerX);
	    var x = 4 * (e.layerY);
    }
    else if (document.all) {
	    var y = 4 * (event.offsetX);
	    var x = 4 * (event.offsetY);
    }
    else {
	    var y = 4 * (e.pageX - Xfixed);
	    var x = 4 * (e.pageY - Yfixed);//alert (document.getElementById('Xfixed').value + "," + e.pageX + "," + document.getElementById('Yfixed').value + "," + e.pageY);
    }

    sx = x - 512;
    sy = y - 512;
    qx = (sx < 0)?0:1;
    qy = (sy < 0)?0:1;
    q = 2 * qy + qx;
    quad = new Array(-180,360,180,0);
    xa = Math.abs(sx);
    ya = Math.abs(sy);
    d = ya * 45 / xa;
    if(ya > xa) d = 90 - (xa * 45 / ya);
    deg = Math.floor(Math.abs(quad[q] - d));
    n = 0;
    sx = Math.abs(x - 512);
    sy = Math.abs(y - 512);
    r = Math.sqrt((sx * sx) + (sy * sy));
    if(x == 512 & y == 512) {
	    c = "000000";
    }
    else {
	    for(i = 0; i < 3; i++) {
		    r2 = clrary[deg][i] * r / 256;
		    if(r > 256) r2 += Math.floor(r - 256);
		    if(r2 > 255) r2 = 255;
		    n = 256 * n + Math.floor(r2);
	    }
	    c = n.toString(16);
	    while(c.length < 6) c = "0" + c;
    }
    if(document.layers) { //alert ('t0');
	    document.layers["wheel"].document.getElementById('colorv').value = "#" + c;
	    document.layers["wheel"].bgColor = "#" + c;
    }
    else if (document.all){ //alert ('t1');
	    document.all["wheel"].document.getElementById('colorv').value = "#" + c;
	    document.all["wheel"].style.backgroundColor = "#" + c;
    }
    else { //alert('t2');
	    document.getElementById('colorv').value = "#" + c;
	    document.getElementById('wheel').style.backgroundColor = "#" + c;
    }
    return false;
}

function stop(a,b){
    var k = eval("document." + a + "." + b);
    k.value = document.getElementById('colorv').value;
    k.style.backgroundColor = document.getElementById('colorv').value;
    document.getElementById('wheel').style.display = 'none';
    offT();
}

function opencolor(a,b) {
	var colorTable = "<div id='wheel' style='width:256px;height:276px;position:relative; left:0px; top:0px; z-index:1;display:inline-block;'>";
		colorTable += "<table border='0' cellpadding='0' cellspacing='0' width='100%'>";
		  colorTable += "<tr>";
			colorTable += "<td>";
			  colorTable += "<img alt='' src='"+direct+"/images/colorwheel.jpg' width='256' height='256'  onclick=\"stop('" + a + "','" + b + "')\" />";
			colorTable += "</td>";
		  colorTable += "</tr>";
		  colorTable += "<tr>";
			colorTable += "<td align='right' height='20'>";
			  colorTable += "<img alt='' src='"+direct+"/images/delete1.gif' style='cursor:pointer' onclick='offT()' />&nbsp;&nbsp;";
			colorTable += "</td><input type='hidden' id='colorv' size='27' />";
		  colorTable += "</tr>";
		colorTable += "</table>";
		colorTable += "</div>";


	popEnterBa();
	//popEnterB('색찾기',colorTable,'256');
	popEnterB1('#A2A2A2','1','#FFFFFF',colorTable,'256','0');

	capture();
}
/*  //보류
function myokfunc(){
	alert("색상이 변경되었습니다.");
}

//init colorpicker:
$(document).ready(
	function()
	{
		$.ColorPicker.init();
	}
);
*/

// color picker (css 파일에 설정 있슴), ToolTip.html 에서 이쪽으로 이동, 상위필요한 코드는 Tooltip.html 에 있음
$(document).ready(function() {
	$('#demo').hide();
	var f = $.farbtastic('#picker');
	var p = $('#pickerParent').css('opacity', 1).hide();

	var selected;
	$('.cwswitch').bind('click', function(event) {
		var currentID = this.title;
		//$('.colorwell').each(function () { f.linkTo('#' + currentID); $('.colorwell').css('opacity', 1); });
		$('#' + currentID).each(function () { f.linkTo('#' + currentID); $('.colorwell').css('opacity', 1); });
		//$('.colorwell')[index]
		$('#' + currentID)
		.focus(function() {
			if (selected) {
				$(selected).css('opacity', 1).removeClass('colorwell-selected');
			}
			f.linkTo(this);
			p.css('opacity', 1);
			$(selected = this).css('opacity', 1).addClass('colorwell-selected');
		});
		p.animate({
			top: event.pageY + 10,
			left: event.pageX
		});
		p.show(500);
	});

	$('#pickerCloser').bind('click', function(event) {
	p.hide();
	});
});

// 레이어 이동
var bdown = false;
var xz, yz, xPosOld, yPosOld, xPosMove, yPosMove, xPosNow, yPosNow, targetField, target;
var sElem;
var zidx = 10000;
/*
function setInit(){
	var divs = ["DivTree01", "DivTree02", "DivSignBoard01", "DivHouseLevel01_3", "DivHouseLevel01_1", "DivHouseLevel02_1", "DivBall01", "DivTube01"];
	var divsLength = divs.length;

	for (var i=0; i<divsLength; i++){
		xPosOld = document.getElementById(divs[i]).offsetLeft;
		yPosOld = document.getElementById(divs[i]).offsetTop;
		savePos = xPosOld+","+yPosOld;
		targetField = document.getElementById(divs[i]).getAttribute("rel");
		document.getElementById(targetField).value = savePos;
	}
}
*/
function getPosition(obj){
	$('.drag').mouseover(function() {
		var topValue= 0,leftValue= 0;
		while(obj){
			leftValue += obj.offsetLeft;
			topValue += obj.offsetTop;
			obj = obj.offsetParent;
		}
		saveValue = leftValue + "," + topValue;
		return saveValue;
	});
}
function mdown(){
	bdown = true;
	//sElem = event.srcElement;
	sElem = $('.drag');
	xz = event.clientX;
	yz = event.clientY;
	sElem.css('zindex',zidx + 1);
	zidx++;
	$('.drag').mouseleave(function() {
		document.onmousemove = get_mouse;
	});
}
function mup(){
	bdown = false;
	getPosition(sElem);
	$('.drag').mouseleave(function() {
		document.onmousemove = get_mouse;
	});
}
function moveimg(){
	if(bdown) {
		var distX = event.clientX - xz;
		var distY = event.clientY - yz;

		sElem.css('left',parseInt(sElem.position().left) + distX + 'px').css('top',parseInt(sElem.position().top) + distY + 'px');

		xz = event.clientX;
		yz = event.clientY;

		return false;
	}
	$('.drag').mouseleave(function() {
		document.onmousemove = get_mouse;
	});
}

//document.onmousedown = mdown;
document.onmousedown = get_mouse;
//document.onmouseup = mup;
document.onmouseup = get_mouse;
//document.onmousemove = moveimg;
document.onmousemove = get_mouse;
//window.onload = setInit;
//-->

//전체위치조정
function resetTT() {
	var sh = $(window).scrollTop();
	$('#tooltipBase').css('top','-'+sh+'px');
}
$(window).load(resetTT).resize(resetTT).scroll(resetTT);

/*

# Tooltip ver 1.1.0
xhtml 에 맞추기 위하여
- .left, .top 에 값 넣을때 + 'px' 붙였음
- document.body.scrollTop/Left 을 dument.documentElement.scrollTop/Left 으로 수정 (크롬은 그대로)

# Tooltip ver 1.2.0
color picker Jquery 붙였음. 칼라선택할 때 이용 가능

# Tooltip ver 1.2.1
각 브라우져별 스크롤 높이 계산법을 다르게 설정

# Tooltip ver 1.2.2
각 브라우져별 스크롤 높이 계산법 정정. drag 할때 방식 수정

# Tooltip ver 1.3.0
drag 방식을 jquery를 이용한 방식으로 수정

# Tooltip ver 1.4.0
전체적인 위치를 코드의 어느 위치에 있든 상관없이 적용되도록 수정(tooltipBase 이용)
*/