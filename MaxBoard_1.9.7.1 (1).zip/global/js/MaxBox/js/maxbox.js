/*! MaxBox v1.3.1
# 저작자 : 이준규(Max Yi, maxhellovan@gmail.com)*/

// 변수설정
var editor;
var mbox_padding = 10; //기본 패딩
var mbox_bgcolor = '#ffffff'; //박스 내부 배경 기본색
var mbox_bordercolor = '#a6a6a6'; //박스테두리 기본색
var mbox_borderpx = 5; //박스테두리 두께(픽셀)
var mbox_radius = 5; //박스 모서리 라운딩처리 (0이면 직각)
var this_js_img = "/global/js/MaxBox/img"; //현재 MaxBox의 img 폴더 위치 (ie용)

function checkBroswer_maxbox(){

	var agent = navigator.userAgent.toLowerCase(),
	name = navigator.appName,
	browser = '',
	os = '';

	var opt = new Array();

	// MS 계열 브라우저를 구분
	if(name === 'Microsoft Internet Explorer' || agent.indexOf('trident') > -1 || agent.indexOf('edge/') > -1) {
		browser = 'ie';
		if(name === 'Microsoft Internet Explorer') { // IE old version (IE 10 or Lower)
			agent = /msie ([0-9]{1,}[\.0-9]{0,})/.exec(agent);
			browser += parseInt(agent[1]);
		}
		else { // IE 11+
			if(agent.indexOf('trident') > -1) { // IE 11
				browser += 11;
			} else if(agent.indexOf('edge/') > -1) { // Edge
				browser = 'edge';
			}
		}
	}
	else if(agent.indexOf('safari') > -1) { // Chrome or Safari
		if(agent.indexOf('opr') > -1) { // Opera
			browser = 'opera';
		}
		else if(agent.indexOf('chrome') > -1) { // Chrome
			browser = 'chrome';
		}
		else { // Safari
			browser = 'safari';
		}
	}
	else if(agent.indexOf('firefox') > -1) { // Firefox
		browser = 'firefox';
	}

	if(agent.indexOf('iphone') > -1 || agent.indexOf('ipad') > -1) { // iPhone
		os = 'iOS';
	}
	//alert (agent);
	opt['browser'] = browser;
	opt['os'] = os;

	return (opt);
}

var opt_maxbox = checkBroswer_maxbox();
var browser_maxbox = opt_maxbox['browser'];
var os_maxbox = opt_maxbox['os'];
//var browser_maxbox = checkBroswer_maxbox();

//현재 자바스크립트의 이미지 폴더 위치
if (browser_maxbox.indexOf('ie') != -1) { //ie
	var imgurl = direct + this_js_img;
}
else { //그외 브라우저
	var script = document.currentScript;
	var scriptUrl = script.src;
	var script_tmp = scriptUrl.split('/');
	var this_script = "js/"+script_tmp[script_tmp.length - 1];
	var imgurl = scriptUrl.replace(this_script,'img');
}

$(function() {
	//맥스박스 클래스 삽입된 태그 클릭
	$(document).on('click','.maxbox',function(e) {
		e.preventDefault(); //기본 동작 금지
		var mbox_url = null;
		var mbox_tmp = null;
		var mbox_x = null;
		var mbox_y = null;
		var mbox_showAll = null;
		var this_tag = $(this)[0].tagName.toLowerCase();
		if (this_tag == 'a') {
			mbox_url = $(this).prop('href');
			mbox_tmp = $(this).attr('alt');
			if (mbox_tmp) {
				if (mbox_tmp.indexOf('@*@') > -1) {
					var tmp = mbox_tmp.split('@*@');
				}
				else {
					var tmp = mbox_tmp.split('|*|');
				}

				if (tmp[1]) mbox_x = tmp[1];
				if (tmp[2]) mbox_y = tmp[2];
			}
		}
		else if (this_tag == 'img') {
			mbox_url = $(this).prop('src');
			mbox_tmp = $(this).attr('alt');
			if (mbox_tmp) {
				if (mbox_tmp.indexOf('@*@') > -1) {
					var tmp = mbox_tmp.split('@*@');
				}
				else {
					var tmp = mbox_tmp.split('|*|');
				}

				if (tmp[0]) {
					if (tmp[0] != '' && tmp[0] != undefined) {
						mbox_url = tmp[0];
					}
				}
				if (tmp[1]) {
					if (tmp[1] != '' && tmp[1] != undefined) {
						mbox_x = tmp[1];
					}
				}
				if (tmp[2]) {
					if (tmp[2] != '' && tmp[2] != undefined) {
						mbox_y = tmp[2];
					}
				}
				if (tmp[3]) {
					if (tmp[3] == '1') {
						mbox_showAll = 1;
					}
					else if (tmp[3] != '') {
						mbox_showAll = tmp[3];
					}
				}
			}
		}
		else {
			mbox_tmp = $(this).attr('alt');
			if (mbox_tmp) {
				if (mbox_tmp.indexOf('@*@') > -1) {
					var tmp = mbox_tmp.split('@*@');
				}
				else {
					var tmp = mbox_tmp.split('|*|');
				}

				if (tmp[0]) mbox_url = tmp[0];
				if (tmp[1]) mbox_x = tmp[1];
				if (tmp[2]) mbox_y = tmp[2];
			}
		}

		//console.log(mbox_tmp + ' : ' + mbox_url + ' : ' + mbox_x + ' : ' + mbox_y);
		maxbox(this_tag, mbox_url, mbox_x, mbox_y, mbox_showAll);
	});


	if (os_maxbox == 'iOS') {
		$(document).on('scroll touchmove mousewheel','.mbx_win', function(e){
			e.preventDefault();
			e.stopPropagation();
			return false;
		});
	}

});

function triggerclick(clsname, idxnum) {
	//console.log(clsname,idxnum)
	//console.log($('.'+clsname))
	//console.log($('.'+clsname)[idxnum])
	var cls = $('.'+clsname)[idxnum];
	$(cls).trigger('click');
}

var mbox_w = null;
var mbox_h = null;
var mbox_showAll = null;
var clickClass = null;

//맥스박스 실행
function maxbox(t,u,x,y,s) {
	//t: tag, u: url, x: width, y: height
	//$('.mbx_bg').remove();
	if (t && t != 'undefined' && u) {//console.log(t + ' , ' + u + ' , ' + x + ' , ' + y + ' , ' + s);
		if (x) mbox_w = x;
		else mbox_w = null;
		if (y) mbox_h = y;
		else mbox_h = null;

		if (s) mbox_showAll = s;
		else mbox_showAll = null;

		//이미지 전부보여주기인 경우
		if (mbox_showAll != null) {
			//maxbox클래스가 선언된 태그를 전부 찾는다
			var this_tag = ''
			var tn = 0;
			var tnNow = 0;
			var mbimgA = [];
			var mbox_tmp_alt = '';
			var this_src = '';


			//전체 이미지를 보여줌
			if (mbox_showAll == 1) {

				$('.maxbox').each(function () { //console.log('mb')
					//console.log($(this).prop('src'), u)

					//비교될 이미지 소스 추출
					mbox_tmp_alt = $(this).attr('alt');
					if (mbox_tmp_alt.indexOf('@*@') > -1) {
						var tmp_alt = mbox_tmp_alt.split('@*@');
					}
					else {
						var tmp_alt = mbox_tmp_alt.split('|*|');
					}

					this_src = $(this).prop('src');
					if (tmp_alt[0]) {
						if (tmp_alt[0] != '' && tmp_alt[0] != undefined) {
							this_src = tmp_alt[0];
						}
					}

					this_tag = $(this)[0].tagName.toLowerCase(); //console.log(this_tag);
					//이미지인 경우만
					if (this_tag == 'img') { //console.log('h')
						mbimgA[tn] = this_src;
						if (mbimgA[tn] == u) { //console.log('g')
							tnNow = tn;
						}
						tn++;
					}
				})

				clickClass = 'maxbox';
			}
			//같은 클래스명인 태그들을 찾는다
			else {
				$('.' + mbox_showAll).each(function () { //console.log('mb')
					//console.log($(this).prop('src'), u)

					//비교될 이미지 소스 추출
					mbox_tmp_alt = $(this).attr('alt');
					if (mbox_tmp_alt.indexOf('@*@') > -1) {
						var tmp_alt = mbox_tmp_alt.split('@*@');
					}
					else {
						var tmp_alt = mbox_tmp_alt.split('|*|');
					}

					this_src = $(this).prop('src');
					if (tmp_alt[0]) {
						if (tmp_alt[0] != '' && tmp_alt[0] != undefined) {
							this_src = tmp_alt[0];
						}
					}

					//같은 클래스명인 태그들을 찾는다
					this_tag = $(this)[0].tagName.toLowerCase();
					//이미지인 경우만
					if (this_tag == 'img') { //console.log('h')
						mbimgA[tn] = this_src;
						if (mbimgA[tn] == u) { //console.log('g')
							tnNow = tn;
						}
						tn++;
					}
				})

				clickClass = mbox_showAll;
			}

			var prevImg = null;
			var nextImg = null;
			//이미지가 2개인 경우(0,1)
			if (tn == 2) {
				if (tnNow == 0) {
					prevImg = 1;
					nextImg = 1;
				}
				else {
					prevImg = 0;
					nextImg = 0;
				}
			}
			//이미지가 3개 이상인 경우(0,1,2,....)
			else if (tn > 2) {
				if (tnNow == 0) {
					prevImg = tn - 1;
					nextImg = 1;
				}
				else if (tnNow == tn - 1) {
					prevImg = tn-2;
					nextImg = 0;
				}
				else {
					prevImg = tnNow - 1;
					nextImg = tnNow + 1;
				}
			}
		}

		$('html,body').css('overflow','hidden');
        //console.log('mbx_gb length : ',$('.mbx_bg').length)
		if ($('.mbx_bg').length == 0) {
			var mbx_back = document.createElement('div');
			mbx_back.className = 'mbx_bg';
			$('body').append(mbx_back);
		}
		else {
			$('.mbx_win').fadeOut().remove();
			$('.mbx_close').remove();
		}

		if (t != 'direct') {
			if (t != 'img') var contmb = "<iframe src='" + u + "' id = 'mbFrame' style='width:100%;'></iframe>";
			else var contmb = "<img src='" + u + "' id='mbImg' style='width:100%;max-width:100%;'>";
		}
		else {
			var contmb = "<div style='overflow:auto;'>" + u + "</div>";
		}
		$('.mbx_bg').css('position','fixed').css('top','0').css('left','0').css('text-align','center').css('background-color','rgba(0,0,0,0.5)').css('z-index','100000').append("<div class='mbx_win' style='position:absolute;margin:0 auto;display:none;border:" + mbox_borderpx + "px solid " + mbox_bordercolor + ";background-color:" + mbox_bgcolor + ";border-radius:" + mbox_radius + "px;overflow:auto; -webkit-overflow-scrolling:touch;'>" + contmb + "</div><div class='mbx_close' style='position:absolute;top:0;right:0;width:20px;height:20px;padding:5px;background-color:rgba(0,0,0,0.5);cursor:pointer;display:none;' onclick='maxbox_close();'><img src='" + imgurl + "/x2.png' style='width:20px;height:20px;'></div>");

		if (prevImg != null && nextImg != null) {
			$('.maxArrowBtn').remove();
			$('.mbx_bg').append("<img src='" + imgurl + "/prev3.png' class='maxArrowBtn maxPrevBtn' style='height:50px;position:fixed;cursor:pointer;display:none;opacity:0.5;' onclick=\"triggerclick('"+clickClass+"', " + prevImg + ")\"><img src='" + imgurl + "/next3.png' class='maxArrowBtn maxNextBtn' style='height:50px;position:fixed;cursor:pointer;display:none;opacity:0.5;' onclick=\"triggerclick('"+clickClass+"', " + nextImg + ")\">");
		}

		maxbox_chgsize();
		//setTimeout(maxbox_chgsize,200);
	}
}

//맥스박스 닫기
function maxbox_close() {
	$('html,body').css('overflow','auto');
	if (os_maxbox == 'iOS') {
		$(document).off('scroll touchmove mousewheel','.mbx_win');
	}
	$('.mbx_bg').remove();

	if(typeof after_maxbox_close == 'function' ) {
		after_maxbox_close();
	}
}

//맥스박스 크기조정
function maxbox_chgsize() {
	if (document.body && document.body.offsetWidth) {
		var width = document.body.clientWidth;
		var height = document.body.clientHeight;
	}
	if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
		var width = document.documentElement.clientWidth;
		var height = document.documentElement.clientHeight;
	}
	if (window.innerWidth && window.innerHeight) {
		var width = window.innerWidth;
		var height = window.innerHeight;
		//var width = $('body').innerWidth();
		//var height = $('body').innerHeight();
	}

	var mbox_w_px = 0;
	var mbox_h_px = 0;
	var mbxwin_l = 0;
	var mbxwin_t = 0;

	if (mbox_w == null) var mbox_w_max_px = 1000;
	else {
		if (mbox_w.indexOf('px') != -1) {
			var mbox_w_max_px = mbox_w.replace(/px/gi,'');
		}
		else if (mbox_w.indexOf('%') != -1) {
			var mbox_w_pc = mbox_w.replace(/\%/gi,'');
			var mbox_w_max_px = width * parseInt(mbox_w_pc) / 100;
		}
		else {
			var mbox_w_max_px = parseInt(mbox_w);
		}
	}

	//console.log(mbxwin_l)
	if (mbox_h == null) {
		var mbxwin_h = height - 60 - (mbox_borderpx * 2);
	}
	else {
		if (mbox_h.indexOf('px') != -1) {
			var mbox_h_px = mbox_h.replace(/px/gi,'');
		}
		else if (mbox_h.indexOf('%') != -1) {
			var mbox_h_pc = mbox_h.replace(/\%/gi,'');
			var mbox_h_px = height * parseInt(mbox_h_pc) / 100;
		}
		else var mbox_h_px = mbox_h;
		var mbxwin_h = mbox_h_px;
	}

	//var mbox_h_px = $('#mbImg').get(0).naturalHeight;

	//console.log(width,mbox_w_max_px)

	/*
	if (height > (parseInt(mbox_h_max_px) + (mbox_borderpx * 2) + 10)) {
		if ($('#mbImg').length > 0) {
		    //var mbxwin_h = $('#mbImg').get(0).naturalHeight;
			//console.log('mbImgH',mbox_h_px);
		}
	}
	*/

	if (width > (parseInt(mbox_w_max_px) + (mbox_borderpx * 2) + 10) || $('#mbImg').length > 0) {
		//console.log('mbx_win',$('.mbx_win').width());
		//console.log('mbImg',$('#mbImg').width());
		//console.log($('#mbImg'))
		//if ($('#mbFrame').width())

		function chgSizeImg() {
			//console.log('width1',width)
			mbox_w_px = $('#mbImg').get(0).naturalWidth;
			mbox_h_px = $('#mbImg').get(0).naturalHeight;

			//console.log('mbImg',mbox_w_px,mbox_h_px);

			var mbox_hx = 0;
			if (mbox_w_max_px >= mbox_w_px) {
				mbox_hx = mbox_h_px;
			}
			else {
				mbox_hx = mbox_w_max_px * mbox_h_px / mbox_w_px;
			}

			if (mbxwin_h > mbox_hx) {
				mbxwin_h = mbox_hx;
			}

			mbxwin_l = (width - parseInt(mbox_w_px) - (mbox_borderpx * 2)) / 2;
			mbxwin_t = (height - mbxwin_h - (mbox_borderpx * 2)) / 2;

			$('.mbx_bg').css('width',width+'px').css('height',height+'px');
			$('.mbx_win').css('left',mbxwin_l+'px').css('width', mbox_w_px + 'px').css('max-width', mbox_w_max_px + 'px').css('height', mbxwin_h + 'px').css('top',(mbxwin_t) + 'px');
			$('.mbx_win iframe').css('width', mbox_w_px + 'px').css('max-width', mbox_w_max_px + 'px').css('-webkit-overflow-scrolling','touch').css('background-color','#ffffff');

			$('.maxPrevBtn').css('left',((width - parseInt($('.mbx_win').css('width').replace(/px/gi,'')))/2 + 10) + 'px');
			$('.maxNextBtn').css('left',((width - parseInt($('.mbx_win').css('width').replace(/px/gi,'')))/2 + parseInt($('.mbx_win').css('width').replace(/px/gi,'')) - 33) + 'px');
			$('.maxArrowBtn').css('top',((height - 50)/2) + 'px').css('display','block');

			if ($('.mbx_win').length > 0 && $('.mbx_close').length > 0) {
				var mbxw = parseInt($('.mbx_win').css('width').replace(/px/gi,''));
				var mbxch = parseInt($('.mbx_close').css('height').replace(/px/gi,''));
				$('.mbx_close').css('right',((width - mbxw) / 2) + 'px').css('top', (mbxwin_t + mbox_borderpx) + 'px').css('display','block');
			}

			//console.log('mbxwin top',$('.mbx_win').css('top'));
			//console.log('close top',$('.mbx_close').css('top'));
		}

		//이미지 로드를 위해 별도로 작성
		if ($('#mbImg').length > 0) { //console.log('width',width)
			//console.log('img width',$('#mbImg').width())
			if ($('#mbImg').width() < 200) {
				$('#mbImg').load(chgSizeImg);
			}
			else {
				chgSizeImg();
			}
		}
		else {
			mbox_w_px = mbox_w_max_px;
			$('.mbx_bg').css('display','block');
			$('.mbx_close').css('display','block');
		}
	}
	else {
		mbox_w_px = width - (mbox_borderpx * 2) - 10;
		$('.mbx_bg').css('display','block');
		$('.mbx_close').css('display','block');
	}

	//이미지 타입이 아닌경우
	if ($('#mbImg').length == 0) {
		//console.log(width,mbox_w_px,mbox_borderpx)
		mbxwin_l = (width - parseInt(mbox_w_px) - (mbox_borderpx * 2)) / 2;

		$('.mbx_bg').css('width',width+'px').css('height',height+'px');
		$('.mbx_win').css('left',mbxwin_l+'px').css('width', mbox_w_px + 'px').css('max-width', mbox_w_max_px + 'px').css('height', mbxwin_h + 'px');
		$('.mbx_win iframe').css('width', mbox_w_px + 'px').css('max-width', mbox_w_max_px + 'px').css('-webkit-overflow-scrolling','touch').css('background-color','#ffffff');

		//console.log('mbx_win with : ', $('.mbx_win').css('width'));
	}


	if ($('.mbx_win').length > 0) {
		var mbx_win_t = (height - parseInt($('.mbx_win').css('height').replace(/px/gi,''))) / 2;
		$('.mbx_win').css('top',(mbx_win_t - mbox_borderpx) +'px');
		//console.log('mbxwin top ori',$('.mbx_win').css('top'))
	}

	if (os_maxbox == 'iOS') {
		$('.mbx_win').css('overflow','auto');
		$('.mbx_win iframe').css('height', '101%');
	}
	else {
		if ($('#mbImg').length > 0) {
			$('.mbx_win').css('overflow','auto').css('height', mbxwin_h + 'px');
		}
		else {
			$('.mbx_win').css('overflow','hidden');
			$('.mbx_win iframe').css('height', mbxwin_h + 'px').css('overflow','hidden');
		}
	}
	//alert('os : ' + os_maxbox);
	$('.mbx_win > div').css('width', mbox_w_px + 'px').css('max-width', mbox_w_max_px + 'px').css('height', mbxwin_h + 'px').css('max-height', mbxwin_h + 'px').css('overflow','auto').css('-webkit-overflow-scrolling','touch');


	//alert ($('.mbx_win').css('width') + ':' + $('.mbx_win').css('height') + ' , ' + $('.mbx_win iframe').css('width') + ':' + $('.mbx_win iframe').css('height'));

	//이미지 타입이 아닌경우
	if ($('#mbImg').length == 0) {
		if ($('.mbx_win').length > 0 && $('.mbx_close').length > 0) {
			var mbxw = parseInt($('.mbx_win').css('width').replace(/px/gi,''));
			var mbxch = parseInt($('.mbx_close').css('height').replace(/px/gi,''));
			$('.mbx_close').css('right',((width - mbxw) / 2) + 'px').css('top', mbx_win_t + 'px');
		}
	}
    //console.log('mbx_win img : ',$('.mbx_win img').length)
	if ($('.mbx_win img').length > 0) {
		//$(".mbx_win").find("img").load(function(){
		$(".mbx_win img").load(function(){

			$('.mbx_win').css('display','block');
		});
	}
	else $('.mbx_win').css('display','block');
	//});
}

$(window).resize(maxbox_chgsize);