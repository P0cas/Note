var isMoving = false;
var slide_width;
var slide_height;

$(function(){
	var img_cnt = $('.slide_back').children('div').length;
	if (img_cnt > 0) {
		$('.slide_back').after("<div class='dots'><div></div></div>");
		for (var x=1; x<=img_cnt; x++) {
			$('.dots').children('div').append("<div id='dot"+x+"'></div>");
		}
	}

	slide_width = $('.slide').css('width').replace(/px/gi,'');
	slide_height = Math.round(parseInt(slide_width) * 3 / 4);

	$('.slide').css('height', slide_height + 'px');
	$('.slide_back').css('height', slide_height + 'px').css('width', (parseInt(slide_width) * img_cnt) + 'px');
	$('.slide_back').children('div').css('width', slide_width + 'px');

	$(document).on('click','.prev',function() {
		if (isMoving == false) move_slide ('prev');
	}).on('click','.next',function() {
		if (isMoving == false) move_slide ('next');
	});
});

function move_slide (a) {
	isMoving = true;
	var mib = parseInt($('.slide').css('width').replace(/px/gi,''));
	console.log(mib);
	if (a == 'prev') {
		$('.slide_back > div').last().prependTo('.slide_back');
		$('.slide_back').css('left','-'+mib+'px');
		$('.slide_back').animate({left:'0'},300,function() {
			$('.dots > div > div').css('background-color','#999');
			var this_itid = $('.slide_back > div').first().attr('id').replace('img','');
			console.log(this_itid)
			$('#dot'+this_itid).css('background-color','#2EBDBA');
			isMoving = false;
		});
	}
	else if (a == 'next') {
		$('.slide_back').animate({left:'-'+mib+'px'},300,function() {
			$('.dots > div > div').css('background-color','#999');
			$('.slide_back').css('left','0');
			$('.slide_back > div').first().appendTo('.slide_back');
			var this_itid = $('.slide_back > div').first().attr('id').replace('img','');
			console.log(this_itid)
			$('#dot'+this_itid).css('background-color','#2EBDBA');
			isMoving = false;
		});
	}
}

var t_start_x = null;
var t_start_y = null;
var t_end_x = null;
var t_end_y = null;

$(document).on('touchstart', '.slide', function(e) {
	t_start_x = event.touches[0].screenX;
	t_start_y = event.touches[0].screenY;
	t_end_x = t_start_x;
	t_end_y = t_start_y;
}).on('touchmove', '.slide', function(e) {
	var event = e.originalEvent;

	t_end_x = event.touches[0].screenX;
	t_end_y = event.touches[0].screenY;

}).on('touchend', '.slide', function(e) {
	var t_x = t_end_x - t_start_x;
	var t_y = Math.abs(t_end_y - t_start_y);
	var t_ratio = t_y / Math.abs(t_x);
	//console.log('t_ratio : ' + t_ratio + ' : ' + t_end_x + ' : ' + t_start_x)
	if (t_end_x > t_start_x) {
		if (t_x > 10) {
			var coln = Math.floor(parseInt($('.slide').scrollLeft()) / parseInt(slide_width));

			console.log('column number : ' + coln)
			var pos = coln * parseInt(slide_width);

			if (isMoving == false) {
				move_slide('prev')
			}

		}
		else {
			var coln = Math.floor(parseInt($('.slide').scrollLeft()) / parseInt(slide_width)) + 1;

			console.log('오른쪽으로 스와이프 실패 t_x : ' + t_x)
			var pos = coln * parseInt(slide_width);
		}
	}
	else if (t_end_x < t_start_x) {
		if (t_x < -10) {
			var coln = Math.floor(parseInt($('.slide').scrollLeft()) / parseInt(slide_width)) + 1;

			console.log('column number : ' + coln)
			var pos = coln * parseInt(slide_width);

			if (isMoving == false) {
				move_slide('next')
			}
		}
		else {
			var coln = Math.floor(parseInt($('.slide').scrollLeft()) / parseInt(slide_width));

			console.log('왼쪽으로 스와이프 실패 t_x : ' + t_x)
			var pos = coln * parseInt(slide_width);
		}
	}
	else {

	}
});