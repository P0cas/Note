var NewConturl = direct + "/global/ajaxNewCont.html";
var chknewcont;
function NewContChk(a,b) {
	clearInterval(chknewcont);
	clearTimeout(chknewcont);
	jQuery.ajaxSettings.traditional = true;
	$.post(
		NewConturl,
		{
			a:a,
			b:b
		},
		function (data) {
			var res = data.split("tryloginagain"); //alert (res.length);
			if (res.length == 2) {
				alert ("세션이 종료되었습니다. 다시 로그인해 주십시오.");
				location.reload();
			}
			else if (data != '') {
				var tmp = data.split("|*|");
				//if (tmp[2] != '') $('#newcont').prepend(document.getElementById('newcont').innerHTML = tmp[2] + document.getElementById('newcont').innerHTML;
				if (tmp[2] != '') $('#newcont').prepend(tmp[2]);
				chknewcont = setTimeout("NewContChk('" + tmp[1]  + "','');",55000);
			}
		}
	);
}