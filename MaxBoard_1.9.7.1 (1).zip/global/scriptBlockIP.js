var BlockIPurl = "../global/ajaxBlockIP.html";
var conip = "";

function BlockIPChk(a) { //alert ('c');
	var answer = confirm("'" + a + "' IP 를 차단하시겠습니까? \n차단된 아이피는 웹사이트에 접속할수 없으며,\n사이트관리 > 사이트관리 > 사이트보안 > 금지IP 에 자동 추가됩니다.\n금지IP 리스트에서 빼면 접속이 가능하게됩니다.");
	if (answer == true) {
		conip = a;
		if (httpBlockIP.readyState == 4 || httpBlockIP.readyState == 0) {//alert (lastNum);
			httpBlockIP.open("GET",BlockIPurl + '?a=' + a,true);
			httpBlockIP.onreadystatechange = handlehHttpBlockIP; //alert ('d');
			httpBlockIP.send(null);
		}
	}
}

function handlehHttpBlockIP() {
  if (httpBlockIP.readyState == 4) {
	results = httpBlockIP.responseText;   //alert (results);
	var res = results.split("tryloginagain"); //alert (res.length);
	if (res.length == 2) {
		alert ("세션이 종료되었습니다. 다시 로그인해 주십시오.");
		location.reload();
	}
    else {
		var tmp = results.split("|*|");
		if (tmp[1] == 'exists!') {
			alert ("'" + conip + "' IP는 이미 차단 등록된 IP입니다.");
		}
		else if (tmp[1] == 'blocked!') {
			alert ("'" + conip + "' IP가 차단되었습니다.");
		}
	}
  }
}

function getHTTPObject() {
  var xmlhttp;

    try {
      xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
      try {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
      } catch (E) {
        xmlhttp = false;
      }
    }

  if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
    try {
      xmlhttp = new XMLHttpRequest();
    } catch (e) {
      //xmlhttp = false;
	  try
        {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (e)
        {
            alert("지원되지 않는 브라우저입니다.");
        }
    }
  }
  return xmlhttp;
}

var httpBlockIP = getHTTPObject();
