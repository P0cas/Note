var StatLogPassurl = "../global/StatLogPass.html";

function StatLogPassChk() { //alert ('c');
	if (httpStatLogPass.readyState == 4 || httpStatLogPass.readyState == 0) {//alert (lastNum);
		var pointD = document.getElementById('pointDate').value; //alert (pointD);
  	    httpStatLogPass.open("GET",StatLogPassurl + '?a='+pointD,true);
        httpStatLogPass.onreadystatechange = handlehHttpStatLogPass; //alert ('d');
  	    httpStatLogPass.send(null);
	}
}

function handlehHttpStatLogPass() {
  if (httpStatLogPass.readyState == 4) {
	results = httpStatLogPass.responseText;   //alert (results);
	if (results != '') {
		document.getElementById('logTable').innerHTML = results;
		setTimeout("StatLogPassChk();",5000);
	}
  }
}

function getHTTPObject() {
  var xmlhttp;

    try {
      xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
      try {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
      } catch (E) {
        xmlhttp = false;
      }
    }

  if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
    try {
      xmlhttp = new XMLHttpRequest();
    } catch (e) {
      //xmlhttp = false;
	  try
        {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (e)
        {
            alert("지원되지 않는 브라우저입니다.");
        }
    }
  }
  return xmlhttp;
}

var httpStatLogPass = getHTTPObject();
