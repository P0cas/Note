var StatMainurl = direct + "/global/ajaxStatMain.html";
var chksm;
function StatMainChk(a,b,c,d) {
	clearInterval(chksm);
	clearTimeout(chksm);
	jQuery.ajaxSettings.traditional = true;
	$.post(
		StatMainurl,
		{
			a:a,
			b:b,
			c:c,
			d:d
		},
		function (data) {
			var res = data.split("tryloginagain"); //alert (res.length);
			if (res.length == 2) {
				alert ("세션이 종료되었습니다. 다시 로그인해 주십시오.");
				location.reload();
			}
			else if (data != '') {
				var tmp = data.split("|*|");
				if (tmp[1] != '') {
					document.getElementById('hit1').innerHTML = tmp[1];
					HVgo('hit1');
					document.getElementById('hit1up').innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;+" + tmp[2];
					$('#hit1up').fadeIn(1500);
					$('#hit1up').fadeOut(2000);
				}
				if (tmp[4] != '') {
					document.getElementById('visit1').innerHTML = tmp[4];
					HVgo('visit1');
					document.getElementById('visit1up').innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;+" + tmp[5];
					$('visit1up').fadeIn(1500);
					$('visit1up').fadeOut(2000);
				}
				if (tmp[7] != '') {
					document.getElementById('hit2').innerHTML = tmp[7];
					HVgo('hit2');
					document.getElementById('hit2up').innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;+" + tmp[8];
					$('#hit2up').fadeIn(1500);
					$('#hit2up').fadeOut(2000);
				}
				if (tmp[10] != '') {
					document.getElementById('visit2').innerHTML = tmp[10];
					HVgo('visit2');
					document.getElementById('visit2up').innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;+" + tmp[11];
					$('#visit2up').fadeIn(1500);
					$('#visit2up').fadeOut(2000);
				}
				chksm = setTimeout("StatMainChk('" + tmp[0] + "','" + tmp[3] + "','" + tmp[6] + "','" + tmp[9] + "');",60000);
			}
		}
	);
}