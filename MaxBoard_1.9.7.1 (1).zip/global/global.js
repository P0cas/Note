//모니터사이즈 변수화
var screen_w = screen.width;
var screen_h = screen.height;

function pnb_opened_in_window(url,wdo,width) {
	var pnb_h = screen_h - 200;
	var pnb_t = 50;
	var pnb_l = (screen_w - width) / 2;
	window.open(url,wdo,'width='+width+', height='+pnb_h+', top='+pnb_t+', left='+pnb_l+', toolbar=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes');
}

// 서브밋/리셋 폼
function submitF(a,b) {
	answer = confirm(b);
	if (answer == true) eval("document." + a + ".submit()");
	else return false;
}
function resetF(a){
	eval("document." + a + ".reset()");
}

// 플래시 보기1
function display_flash(flash_name,flash_width,flash_height){
	var img_name = flash_name;
	var img_height = flash_height;
	var img_width = flash_width;

	document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="'+img_width+'" height="'+img_height+'"> <param name="movie" value="'+img_name+'"> <param name="quality" value="high"> <param name=wmode value=transparent>')
	document.write('<embed src="'+img_name+'" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+img_width+'" height="'+img_height+'"></embed></object>')
}


// 플래시 보기2
function flashview (dirNswf,fwidth,fheight,params) {

var flashobjec="";

	flashobjec+="		<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"+fwidth+"' height='"+fheight+"'>";
	flashobjec+="      <param name='movie' value='"+dirNswf+"'>";
	flashobjec+="      <param name='wmode' value='transparent'>";
	flashobjec+="      <param name='menu' value='false'>";
	flashobjec+="      <embed src='"+dirNswf+"' width='"+fwidth+"' height='"+fheight+"' quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' menu='false' wmode='transparent'></embed>";
	flashobjec+="    </object>";

	document.write(flashobjec);

}


/* 팝업열기
# a : 팝업으로 열 파일 ex) ../poppic.html
# b : 필요한 변수 ex) pic=23
# x : 팝업할 창의 가로크기
# y : 팝업할 창의 세로크기
# s : 스크롤바 이용여부 ex)1:이용, 0:이용안함, A:자동(창의 크기가 화면사이즈보다 크면 스크롤바 on, 작으면 off
*/

function poppic(a,b,x,y,s){
	var width = screen.width / 2 - (x / 2);
	var height = screen.height / 2 - (y / 2);

	if (s == '1')	window.open(a + '?' + b,'','left=' + width + ', top=' + height + ',width=' + x + ',height=' + y + ',scrollbars=1');
	else if (s == '0') window.open(a + '?' + b,'','left=' + width + ', top=' + height + ',width=' + x + ',height=' + y + ',scrollbars=0');
	else if (s =='A') {
		if (x > screen.width || y > screen.height) window.open(a + '?' + b,'','left=' + width + ', top=' + height + ',width=' + x + ',height=' + y + ',scrollbars=1');
		else window.open(a + '?' + b,'','left=' + width + ', top=' + height + ',width=' + x + ',height=' + y + ',scrollbars=0');
	}
}


/* 지정된 시간에 다른 곳을 이동하기
# a : 대기시간(초단위)
# b : 이동할 위치 ex)index.html , http://xxxx.xxxx.xxx
*/

function startTime(a,b){
	var time= new Date();
	hours= time.getHours();
	mins= time.getMinutes();
	secs= time.getSeconds();
	closeTime=hours*3600+mins*60+secs;
	closeTime+=eval(a); //  시간 설정 단위)초
	Timer(b);
}

function Timer(b){
	var time= new Date();
	hours= time.getHours();
	mins= time.getMinutes();
	secs= time.getSeconds();
	curTime=hours*3600+mins*60+secs;
	if (curTime>=closeTime) {
		if (b == 'close') window.close();
		else if (b == 'back') history.back();
		else if (b == 'refresh') window.location.reload();
		else if (b == 'parent_reload') window.parent.location.reload();
		else location.href= eval("'" + b + "'");
	}
	else{
		window.setTimeout(function(){Timer(b)},1000);
	}
}


/* 문자 체크하기 ##
# onblur="input_check(check, chr, spc, num, eng, kor, spe)"
# check : this 로 입력
# chr : 특수문자를 검색할 경우 '|,|' 로 구분해서 공백없이 입력 ex) @ 와 & 를 검색할 경우 '@|,|&' 로 입력, (입력한 경우-> 포함하면 안됨. 체크않을 경우 "0")
# spc: 공백. 입력한 경우-> 포함하면 안됨 "-", 체크않을 경우 "0";
# num : 숫자.  포함 "+", 포함하면 안됨 "-", 체크않을 경우 "0";
# eng: 영어. 포함 "+", 포함하면 안됨 "-", 체크않을 경우 "0";
# kor: 한글. 포함 "+", 포함하면 안됨 "-", 체크않을 경우 "0";
# spe: 기타 모든 특수문자. 포함 "+", 포함하면 안됨 "-", 체크않을 경우 "0";
#
# 예1) 입력한 글에 특수문자 '$', '^'를 반드시 포함하지 않고 한글도 반드시 포함하면 안될 경우 (특수문자는 '$|,|^', 한글은 '-', 나머지는 '+')
# input_check(this,'$|,|^','0','+','+','+','-','+')
# 예2) 입력한 글이 무조건 숫자와 영어 여야만 하는 경우 (특수문자는 '0', 숫자와 영어는 '+',  한글과 기타 모든 특수문자는 '-',)
# input_check(this,'0','0','+','+','-','-')
# 예3) 공백이 들어가면 안되는 경우
# input_check(this,'0','-','+','+','+','+')
*/

function input_check(check,chr,spc,num,eng,kor,spe) {
	var check_string = check.value;
	var len = check_string.length;
    //alert (check_string + "," + chr + "," + spc + "," + num + "," + eng + "," + kor + "," + spe);
	for (var k=0; k<len; k++) {
		var char_ASCII = check_string.charCodeAt(k);
		var c = escape(check_string);
		var ret = '1';
		if (chr != '0' && chr != '') {
			var out = '0';
			var ch = chr.split("|,|");
			for(var i=0; i<ch.length; i++) {
				if (check_string.substr(k) == ch[i]) {ret = '0';check.value = '';break;}
				else ret = '1';
			}
			if (ret == '0') {alert ("사용할 수 없는 기호가 포함되어 있습니다.");break;}
		}
		if (spc != '0' && c.indexOf("%20") != -1){
			if (spc == '-') {alert ("공백은 입력하실 수 없습니다.");ret = '0';break;}
		}
		if (num != '0' && char_ASCII >= 48 && char_ASCII <= 57 ) {
			if (num == '+') ret = '1';
			else if (num == '-') {alert ("숫자는 입력하실 수 없습니다."); ret = '0';break;}
		}
		if (eng != '0' && ((char_ASCII>=65 && char_ASCII<=90) || (char_ASCII>=97 && char_ASCII<=122))) {
			if (eng == '+') ret = '1';
			else if (eng == '-') {alert ("영어는 입력하실 수 없습니다.");ret = '0';break;}
		}
		if (kor != '0' && c.indexOf("%u") != -1){
			if (kor == '+') ret = '1';
			else if (kor == '-') {alert ("한국어는 입력하실 수 없습니다.");ret = '0';break;}
		}
		if (spe != '0' && ((char_ASCII>=33 && char_ASCII<=47) || (char_ASCII>=58 && char_ASCII<=64) || (char_ASCII>=91 && char_ASCII<=96) || (char_ASCII>=123 && char_ASCII<=126) || (char_ASCII>=145 && char_ASCII<=146) || (char_ASCII>=161 && char_ASCII<=255))){
			if (spe == '+') ret = '1';
			else if (spe == '-') {alert ("특수문자는 사용하실 수 없습니다.");ret = '0';break;}
		}
	}//alert (ret);
	if (ret == '1') return true;
	else if (ret == '0') {check.value = '';return false;}
}


// 이메일체크

function email_check(check) {
	var check_string = check.value;
	if (check_string.indexOf('@') == '-1' || check_string.indexOf('.') == '-1'){
		alert ("정확한 이메일주소를 입력해 주십시오.");
		check.value = "";
		return false;
	}
	else return true;
}


// 전화번호에 '-' 자동삽입해주기

function addDashMem(check){
	var check_string = check.value;
	var check_string = check_string.replace(/-/gi,'');
	if (isNaN(check_string) && check_string != '') {
		alert ('숫자만 입력해주세요');
		check.value = '';
		return false;
	}
	else {
		var len = check_string.length;
		if (len >= 1 && check_string.substr(0,1) == '1'){
			if (len >= 5 && len <= 7){
				var subA = check_string.substr(0,4);
				var subF = check_string.substr(4,4);
				check.value = subA + "-" + subF;
			}
			else if (len >= 8){
				var subA = check_string.substr(0,4);
				var subF = check_string.substr(4,4);
				check.value = subA + "-" + subF;
			}
			else{
				check.value = check_string;
			}
		}
		else if (len >= 2 && check_string.substr(0,2) == '02'){
			if (len >= 3 && len <= 5){
				var subA = check_string.substr(0,2);
				var subF = check_string.substr(2,3);
				check.value = subA + "-" + subF;
			}
			else if (len >= 6 && len <= 9){
				var subA = check_string.substr(0,2);
				var subF = check_string.substr(2,3);
				var subB = check_string.substr(5,4);
				check.value = subA + "-" + subF + "-" + subB;
			}
			else if (len >= 10){
				var subA = check_string.substr(0,2);
				var subF = check_string.substr(2,4);
				var subB = check_string.substr(6,4);
				check.value = subA + "-" + subF + "-" + subB;
			}
			else{
				check.value = check_string;
			}
		}
		else if (len >= 2 && check_string.substr(0,2) != '02'){
			if (len >= 4 && len <= 6){
				var subA = check_string.substr(0,3);
				var subF = check_string.substr(3,3);
				check.value = subA + "-" + subF;
			}
			else if (len >= 7 && len <= 10){
				var subA = check_string.substr(0,3);
				var subF = check_string.substr(3,3);
				var subB = check_string.substr(6,4);
				check.value = subA + "-" + subF + "-" + subB;
			}
			else if (len >= 11){
				var subA = check_string.substr(0,3);
				var subF = check_string.substr(3,4);
				var subB = check_string.substr(7,4);
				check.value = subA + "-" + subF + "-" + subB;
			}
			else{
				check.value = check_string;
			}
		}
		else{
			check.value = check_string;
		}
	}
}

function addDashMemV(check){
	var check_string = check.replace(/-/gi,'');
	var len = check_string.length;
	if (isNaN(check_string) && check_string != '') {
		alert ('숫자만 입력해주세요');
		check = '';
	}
	else {
		if (len >= 1 && check_string.substr(0,1) == '1'){
			if (len >= 5 && len <= 7){
				var subA = check_string.substr(0,4);
				var subF = check_string.substr(4,4);
				check = subA + "-" + subF;
			}
			else if (len >= 8){
				var subA = check_string.substr(0,4);
				var subF = check_string.substr(4,4);
				check = subA + "-" + subF;
			}
			else{
				check = check_string;
			}
		}
		else if (len >= 2 && check_string.substr(0,2) == '02'){
			if (len >= 3 && len <= 5){
				var subA = check_string.substr(0,2);
				var subF = check_string.substr(2,3);
				check = subA + "-" + subF;
			}
			else if (len >= 6 && len <= 9){
				var subA = check_string.substr(0,2);
				var subF = check_string.substr(2,3);
				var subB = check_string.substr(5,4);
				check = subA + "-" + subF + "-" + subB;
			}
			else if (len >= 10){
				var subA = check_string.substr(0,2);
				var subF = check_string.substr(2,4);
				var subB = check_string.substr(6,4);
				check = subA + "-" + subF + "-" + subB;
			}
			else{
				check = check_string;
			}
		}
		else if (len >= 2 && check_string.substr(0,2) != '02'){
			if (len >= 4 && len <= 6){
				var subA = check_string.substr(0,3);
				var subF = check_string.substr(3,3);
				check = subA + "-" + subF;
			}
			else if (len >= 7 && len <= 10){
				var subA = check_string.substr(0,3);
				var subF = check_string.substr(3,3);
				var subB = check_string.substr(6,4);
				check = subA + "-" + subF + "-" + subB;
			}
			else if (len >= 11){
				var subA = check_string.substr(0,3);
				var subF = check_string.substr(3,4);
				var subB = check_string.substr(7,4);
				check = subA + "-" + subF + "-" + subB;
			}
			else{
				check = check_string;
			}
		}
		else{
			check = check_string;
		}
	}

	return check;
}


// 숫자에 컴마 붙여주기

function chkComma(a){
	var rightchar = String(a);
	var tmprc = rightchar.split('.');
	var intn = tmprc[0];
	var minus = "";
	if (intn.substr(0,1) == '-') {
		minus = "-";
		intn = intn.substr(1,intn.length-1);
	}
	var moneychar = '';
	for(var ind=intn.length-1;ind>=0;ind--){
		var splitchar=intn.charAt(ind);
		var moneychar=splitchar+moneychar;
		if(ind%3==intn.length%3 && ind!=0){ moneychar=','+moneychar; }
	}
	if (tmprc.length >= '2') moneychar = moneychar + '.' + tmprc[1];
	moneychar = minus + moneychar;
	return moneychar;
}


//숫자에 컴마 빼주기

function unchkComma(a){
	var moneychar = String(a);
	moneychar = moneychar.replace(/,/gi,'');
	return moneychar;
}


//팝업쿠키처리

function popup_event(a,b,c){
	if(cookieVal(b) != "1") eval("document.getElementById('" + a + "').style.display = 'block'");
	else closeWin(a,b,c);
}
function cookieVal(cookieName){
	var thisCookie = document.cookie.split("; ");
	for(var i=0 ; i<thisCookie.length ; i++){
		if(cookieName == thisCookie[i].split("=")[0]) return thisCookie[i].split("=")[1];
	}
	return "x";
}
function setCookie_event(name, value, expiredays){
	var todayDate = new Date();
	todayDate.setDate(todayDate.getDate() +  expiredays);
	document.cookie = name + "=" + escape(value) + "; path=/; expires=" + todayDate.toGMTString() + ";domain;"
}
function closeWin(a,b,c){
	setCookie_event(b,"1",c);
	eval("document.getElementById('" + a + "').style.display = 'none'");
}
function closeWin_pause(a){
	eval("document.getElementById('" + a + "').style.display = 'none'");
}


/*
############## 필수입력 체크 ################
# empty = "false" 일경우 빈칸확인, iname="아이템명"#
#####################################
*/
function checkSubmit(frm){
	var eleCount = frm.elements.length;
	var ctl = null;
	for(var i=0; i<eleCount; i++){
		ctl = frm.elements[i];
		if(typeof(ctl.empty)!="undefined" && ctl.empty=="false"){
			if(ctl.value=="") {
				alert(ctl.iname + ' : 필수입력 항목입니다.');
				ctl.style.border='2px solid #d30505';
				ctl.focus();
				return false;
			} // end if
		} // end if
	} // end for
} // end function


//보여주기/감추기

function showhide(a) {
	var state = document.getElementById(a).style.display;
	if(state=='block') {
		document.getElementById(a).style.display = 'none';
	}
	else {
		document.getElementById(a).style.display = 'block';
	}
}


// 체크박스 전체선택/비선택

function checkAll(a){
	var N = eval("document." + a + ".cbNum.value");
	//alert (N);
	for (x=1;x<=N;x++) {
		if (eval("document." + a + ".cbA.checked")) {
			eval("document." + a + ".cb" + x + ".checked = 1");
		}
		else {
			eval("document." + a + ".cb" + x + ".checked = 0");
		}
	}
}

// 우편번호 창
function popup_zip(fn, addr1, addr2, zip, direct){
	var url = direct + '/dongpop.html?fn='+fn+'&addr1='+addr1+'&addr2='+addr2+'&zip='+zip;
	var opt = 'scrollbars=1,width=500,height=300';
	window.open(url, "mbzip", opt);
}



/* 평/제곱미터 전환###
# a: PM or MP (PM 이면 평을 미터로, MP 이면 미터를 평으로
# b: id
# c: 변환할 값
*/

function PnM(a,b,c){
	if (a == 'PM' && c != '') var n = Math.round(eval(c) * 3.3058 * 100) / 100;
	else if (a == 'MP' && c != '') var n = Math.round(eval(c) * 0.3025 * 100) / 100;
	else var n = '';
	document.getElementById(b).value = n;
}

/*
function bluring(){
	if(event.srcElement.tagName=="A"||event.srcElement.tagName=="IMG") document.body.focus();
}
document.onfocusin=bluring;
*/

// 추천/반대 처리 Ajax
function chkRecOut(a,b,c) { //alert (a + b + c);
	var xmlhttp;
	try {xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');}
	catch (e) {
	    try {xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');}
	    catch (E) {xmlhttp = false;}
	}
	if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
		if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
		else xmlhttp=new ActiveXObject('Microsoft.XMLHTTP'); // code for IE6, IE5
	}

	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4) {
			var result  = xmlhttp.responseText;
			if (result != '') { //alert (result);
			    var tmp = result.split("|*|");
				if (tmp[1] == 'login') {
					var answer = confirm ('로그인 해야 합니다. 로그인 하시겠습니까?');
					if (answer == true) location.href = './index.html?cname=join&sname=login'
				}
				else if (tmp[1] == 'self') {
					alert ('본인의 글에는 참여하실 수 없습니다.');
				}
				else if (tmp[1] == 'exist') {
					alert ('한번만 참여하실 수 있습니다.');
				}
				else if (tmp[1] == 'ok'){
					//alert (result);
					var idx = a + c; //alert (idx);
					document.getElementById(idx).innerHTML = tmp[2];
				}
			}
		}
	}
	xmlhttp.open('POST', './global/ajax_chkRecOut.html' ,true);
	xmlhttp.setRequestHeader('Content-type','application/x-www-form-urlencoded');
	xmlhttp.send('recout=' + a + '&cmn=' + b + '&cnum=' + c);
}


// 배너 광고 클릭 카운트 증가

banner_CountUp = function( code )
{
	var xmlhttp;
	try {xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');}
	catch (e) {
	    try {xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');}
	    catch (E) {xmlhttp = false;}
	}
	if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
		if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
		else xmlhttp=new ActiveXObject('Microsoft.XMLHTTP'); // code for IE6, IE5
	}

	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			var result  = xmlhttp.responseText;
			//alert("test");
			//alert( result );
			//rs.getID("hotView").innerHTML = result;
		}
	}
	xmlhttp.open("POST", "./global/adCount.html" ,true);
	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmlhttp.send( "mode=adCount&num="+code );
}

//쿠키셋팅
function setCookie (name, value, expiredays){
	var todayDate = new Date();
	todayDate.setDate( todayDate.getDate() + expiredays );
	document.cookie = name + "=" + escape( value ) + "; path=/; expires=" + todayDate.toGMTString() + ";";
}

//쿠키체크
function getCookie(name) {
	var Found = false;
	var start, end;
	var i = 0;

	while (i <= document.cookie.length) {
		start = i;
		end = start + name.length;
		if (document.cookie.substring(start, end) == name) {
			Found = true;
			break;
		}
		i++;
	}

	if (Found == true) {
		start = end + 1;
		end = document.cookie.indexOf(';', start);
		if (end < start) end = document.cookie.length;
		return document.cookie.substring(start, end);
	}
	return '';
}

//로그인아이디 쿠키
function setValueID() {
	if ($('#id').val() != '') {
		if ($("input:checkbox[id='check1']").is(":checked") == true) {
			var fm = $('#id').val();
			setCookie ('mbid', fm, 365);
		}
		else {
			var fm = $('#id').val();
			setCookie ('mbid', '', -1);
		}
	}
	else {
		if ($("input:checkbox[id='check1']").is(":checked") == false) {
			var fm = $('#id').val();
			setCookie ('mbid', '', -1);
		}
		else {
			alert ('아이디를 입력 후에 저장할 수 있습니다.');
			$("input:checkbox[id='check1']").prop("checked", false);
		}
	}
}

//로그인아이디 가져오기
function getValueID() {
	$('#id').val(getCookie('mbid'));
	if ($('#id').val() != '') {
		//$("input:checkbox[id='id']").prop("checked", true);
		$("#check1").prop("checked", true);
	}
	else {
		$('#id').val('');
		//$("input:checkbox[id='id']").prop("checked", false);
		$("#check1").prop("checked", false);
	}
}

//자동로그인 체크
function chk_keep_login() {
	if ($("input:checkbox[id='check']").is(":checked") == true) {
		var answer = confirm('로그인을 유지하면 로그아웃하지 않는 한 로그인한 상태로 페이지가 열립니다.\n휴대폰이 아닌 공공장소에서 사용하는 PC라면 체크하지 마시기 바랍니다.\n로그인유지 기능을 이용하시겠습니까?');
        if (answer == false) {
			$("input:checkbox[id='check']").prop("checked", false);
		}
	}
}

//바이트체크 (limit가 없으면 길이를 반환, limit이 있으면 길이까지의 내용을 반환)
function byte_checker(str,limit) {
	var len = 0;
	var buffer = "";
	for (var i=0; i<str.length; i++) {
		var c = escape(str.charAt(i));
		if (c.length == 1) len++;
		else if (c.indexOf("%u") != -1) len += 2;
		else if (c.indexOf("%") != -1) len += c.length / 3;

		if (limit) {
			if (len <= parseInt(limit)) buffer += str.charAt(i);
			else break;
		}
	}

	if (!limit)	return len;
	else return buffer;
}

//브라우저 크기 체크
function get_wh() {
	if (document.body && document.body.offsetWidth) {
		var width = document.body.clientWidth;
		var height = document.body.clientHeight;
	}
	if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
		var width = document.documentElement.clientWidth;
		var height = document.documentElement.clientHeight;
	}
	if (window.innerWidth && window.innerHeight) {
		var width = window.innerWidth;
		var height = window.innerHeight;
		//var width = $('body').innerWidth();
		//var height = $('body').innerHeight();
	}

	var wh = new Array();
	wh['w'] = width;
	wh['h'] = height;
	return wh;
}