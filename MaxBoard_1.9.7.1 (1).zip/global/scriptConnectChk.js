var Connecturl = direct + "/global/ajaxConnectChk.html";
var chkcon;
function ConnectChk(a) {
	clearInterval(chkcon);
	clearTimeout(chkcon);
	jQuery.ajaxSettings.traditional = true;
	$.post(
		Connecturl,
		{
			a:a
		},
		function (data) {
			var tmp = data.split("|*|");
			var conB = parseInt(tmp[1]);
			if (conB == '' || conB < 60000 || isNaN(conB)) conB = 600000;
			chkcon = setTimeout("ConnectChk('');",conB);
		}
	);
}