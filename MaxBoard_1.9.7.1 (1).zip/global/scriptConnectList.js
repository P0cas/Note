var ConnectListurl = direct + "/global/ajaxConnectList.html";
var conLN = "";
var conL = "";
var listcon;

function ConnectListChk() {
	clearInterval(listcon);
	clearTimeout(listcon);

	var vt = unescape(getCookie('vt'));
	if (vt == '') vt = 'mvre';
	//console.log('vt='+vt);
	jQuery.ajaxSettings.traditional = true;
	$.post(
		ConnectListurl,
		{
			vt:vt
		},
		function (data) {//alert (data);
			var res = data.split("tryloginagain"); //alert (res.length);
			if (res.length == 2) {
				alert ("세션이 종료되었습니다. 다시 로그인해 주십시오.");
				location.reload();
			}
			else {
				var tmp = data.split("|*|");
				if (conLN != tmp[0]) {
					//document.getElementById('connect_list_num').innerHTML = tmp[0];
					$('#connect_list_num').html(tmp[0]);
					conLN = tmp[0];
				}
				if (conL != tmp[1]) {
					//document.getElementById('connect_list').innerHTML = tmp[1];
					$('#connect_list').html(tmp[1]);
					conL = tmp[1];
				}
				listcon = setTimeout("ConnectListChk();",30000);
			}
		}
	);
}

//(18-05-09)쿠키를 이용한 선택옵션 추가 (접속타입(vt) : m:회원,v:방문,r:로봇)
function setVtype() {
	var vtype = "";
	if ($('#vt_m').is(':checked') == true) vtype += 'm';
	if ($('#vt_v').is(':checked') == true) vtype += 'v';
	if ($('#vt_r').is(':checked') == true) vtype += 'r';

	vtype += 'e'; //쿠키존재여부 판단을 위해 뒤에 'e'를 붙여줌(exist)

	setCookie ('vt', vtype, 365);
	ConnectListChk();
}