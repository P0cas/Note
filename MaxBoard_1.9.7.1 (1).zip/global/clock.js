function tick() {
    var hours, minutes, seconds, ap;
    var intHours, intMinutes, intSeconds;
    var today;

    today = new Date();

    intHours = today.getHours();
    intMinutes = today.getMinutes();
    intSeconds = today.getSeconds();

    if (intHours == 0) {
	   hours = "12:";
	   ap = "자정";
    }
	else if (intHours < 5) {
	   hours = intHours+":";
	   ap = "새벽";
    }
	else if (intHours < 12) {
		hours = intHours+":";
		if (intHours < 10) hours = "0" + hours;
		ap = "오전";
	}
	else if (intHours == 12) {
		hours = "12:";
		ap = "정오";
	}
	else if (intHours < 18) {
		intHours = intHours - 12
		hours = intHours + ":";
		ap = "오후";
	}
	else if (intHours < 21) {
		intHours = intHours - 12
		hours = intHours + ":";
		ap = "저녁";
	}
	else {
		intHours = intHours - 12
		hours = intHours + ":";
		if (intHours < 10) hours = "0" + hours;
		ap = "밤";
	}

    if (intMinutes < 10) minutes = "0"+intMinutes+":";
	else minutes = intMinutes+":";

    if (intSeconds < 10) seconds = "0"+intSeconds+" ";
	else seconds = intSeconds+" ";

    timeString = ap+" "+hours+minutes+seconds;

    document.getElementById('Clock').innerHTML = timeString;

    window.setTimeout("tick();", 1000);
}

tick();