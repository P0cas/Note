var commentPassurl = "./global/ajaxcommentPass.html";

function commentPassChk(a,b,c) { //alert ('c');
	if (httpcommentPass.readyState == 4 || httpcommentPass.readyState == 0) {//alert (lastNum);
	    var d = document.getElementById(c).value;
		d = escape(d);
		document.getElementById('comnx').value = b;
  	    httpcommentPass.open("GET",commentPassurl + '?a='+a+'&b='+b+'&c='+c+'&d='+d,true,true);
        httpcommentPass.onreadystatechange = handlehHttpcommentPass; //alert ('d');
  	    httpcommentPass.send(null);
	}
}

function handlehHttpcommentPass() {
  if (httpcommentPass.readyState == 4) {
	results = httpcommentPass.responseText;
	var cmx = document.getElementById('comnx').value
	var EDx = 'ED' + cmx;
	var ed = document.getElementById(EDx).value
	//alert (results);
	if (results == 'ok') {
		if (ed == 'E') {
			var cmnameA = "cnumA" + cmx;
			var cmnameB = "cnumB" + cmx;
			var passwH = "passH" + cmx;
			document.getElementById(cmnameA).style.display = 'none';
			document.getElementById(passwH).style.display = 'none';
			document.getElementById(cmnameB).style.display = 'block';
			document.getElementById(cmnameB).disabled = 0;
		}
		else if (ed == 'D') {
			var formc = "formDelCom" + cmx;
			var passwS = "passS" + cmx;
			eval("document." + formc + ".pw.value = document.getElementById(passwS).value");
			eval("document." + formc + ".delcom.value = 'ok'");
            eval("document." + formc + ".submit()");
		}
	}
	else if (results == 'no') {  //alert (results.length);
	    alert ('비밀번호가 일치하지 않습니다.');
		var paH = "passH" + cmx;
		var paS = "passS" + cmx;
		document.getElementById(paS).value = '';
		document.getElementById(paH).style.display = 'none';
		return false;
	}
  }
}

function getHTTPObject() {
  var xmlhttp;

    try {
      xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
      try {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
      } catch (E) {
        xmlhttp = false;
      }
    }

  if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
    try {
      xmlhttp = new XMLHttpRequest();
    } catch (e) {
      //xmlhttp = false;
	  try
        {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (e)
        {
            alert("지원되지 않는 브라우저입니다.");
        }
    }
  }
  return xmlhttp;
}

var httpcommentPass = getHTTPObject();
