/*! MaxEditor v1.2
# 저작자 : 이준규(Max Yi, maxhellovan@gmail.com) */

//jQuery가 먼저 선행되어야 함
//direct 변수가 선행되어야 함
var editor;
var text_padding = 10; //텍스트 기본 패딩
var editor_bgcolor = '#f6f6f6'; //에디터 배경 기본색
var editor_radius = 5; //에디터 모서리 라운딩처리 (0이면 직각)
var me_lang = "ko"; //언어셋팅(ko:한국어, en:English)

//언어셋팅에 따른 변수들. get_editor함수에서 정의.
var size_full; //(1)
var size_normal;  //(2)
var setmode_editor; //(3)
var setmode_code; //(4)
var title_drag_and_drop_image; //(5)
var alert_image1; //(6)
var alert_image2; //(7)
var warn_image1; //(8)
var warn_image2; //(9)
var warn_image3; //(10)
var warn_image4; //(11)
var warn_image5; //(12)
var warn_image6; //(13)
var warn_image7; //(14)
var warn_image8; //(15)


var zidx = 1000;

function checkBroswer(){

	var agent = navigator.userAgent.toLowerCase(),
	name = navigator.appName,
	browser = '',
	os = '';

	var chk_agent = new Array();

	// MS 계열 브라우저를 구분
	if(name === 'Microsoft Internet Explorer' || agent.indexOf('trident') > -1 || agent.indexOf('edge/') > -1) {
		browser = 'ie';
		if(name === 'Microsoft Internet Explorer') { // IE old version (IE 10 or Lower)
			agent = /msie ([0-9]{1,}[\.0-9]{0,})/.exec(agent);
			browser += parseInt(agent[1]);
		}
		else { // IE 11+
			if(agent.indexOf('trident') > -1) { // IE 11
				browser += 11;
			} else if(agent.indexOf('edge/') > -1) { // Edge
				browser = 'edge';
			}
		}
	}
	else if(agent.indexOf('safari') > -1) { // Chrome or Safari
		if(agent.indexOf('opr') > -1) { // Opera
			browser = 'opera';
		}
		else if(agent.indexOf('chrome') > -1) { // Chrome
			browser = 'chrome';
		}
		else { // Safari
			browser = 'safari';
		}
	}
	else if(agent.indexOf('firefox') > -1) { // Firefox
		browser = 'firefox';
	}

	if(agent.indexOf('iphone') > -1 || agent.indexOf('ipad') > -1) { // Firefox
		os = 'iOS';
	}

	chk_agent['browser'] = browser;
	chk_agent['os'] = os;

	return chk_agent;
}

var agents = checkBroswer();
var browser = agents['browser'];
var os = agents['os'];
//console.log(browser);

$(function() {
	var lastME = $('.maxeditor').length - 1;
	$('.maxeditor').each(function(index) {
		var this_id = $(this).attr('id'); //텍스트박스의 아이디를 추출해낸다
		if (this_id) {
			get_editor(this_id); //해당아이디에 맞는 에디터를 가져온다
			//console.log(index + ' : ' + lastME);
			if (index == lastME) { //console.log('1');
				$(this).queue('fx',function() { //console.log('2');
					DragAndDrop();
				});
			}
		}
	});

	$('.maxeditor').css('overflow','auto').focus();

	$(document).on('click','.maxeditor',function() {
		var this_id = $(this).attr('id');
		me_showhide_submenu(this_id,'all','close');
	});
});

function DragAndDrop() {
	//파일 드래그앤드랍

	/*
	//일반적으로 아래의 코드를 쓰지만
	var obj = $(".dropzone");
	obj.on('dragenter',function (e) ~~~

	//동적 태그에는 일반적인 이벤트가 동작되지 않으므로 아래와 같이 변경해줘야 한다.
	$(document).on('dragenter',".dropzone", function (e)
	*/
	$(document).on('drop',".maxeditor", function (e) {//console.log('enter');

		var files = e.originalEvent.dataTransfer.files;
		//console.log(files.length);
		if(files.length >= 1) {
			e.preventDefault();
			var this_id = $(this).attr('id');
			me_showhide_imgwin(this_id,'open');
			var dzid = 'dropzone_' + this_id
			FileMultiUpload(files, dzid);
		}

	});

	$(document).on('dragenter',".dropzone", function (e) {//console.log('enter');
		e.stopPropagation();
		e.preventDefault();
		$(this).css('border', '2px solid #5272A0');
		//console.log('dragenter');
		//restoreSelection('dragenter');
		e.returnValue = false;
	});

	$(document).on('dragleave',".dropzone", function (e) {//console.log('leave');
		e.stopPropagation();
		e.preventDefault();
		$(this).css('border', '2px dotted #8296C2');
		//console.log('dragleave');
		//restoreSelection('dragleave');
		e.returnValue = false;
	});

	$(document).on('dragover',".dropzone", function (e) {//console.log('over');
		e.stopPropagation();
		e.preventDefault();
		//console.log('dragover');
		//restoreSelection('dropzone');
		e.returnValue = false;
	});

	$(document).on('drop',".dropzone", function (e) {//console.log('drop');
		e.preventDefault();
		$(this).css('border', '2px dotted #8296C2');
		//restoreSelection('drop');
		//console.log('drop');

		var files = e.originalEvent.dataTransfer.files;
		if(files.length < 1)
		return;

		var this_id = $(this).attr('id'); //console.log(this_id);

		//FileMultiUpload(files, obj, this_id);
		FileMultiUpload(files, this_id);
	});
}

function FileMultiUpload(files, id) {
	//if(confirm(files.length + "개의 파일을 업로드 하시겠습니까?")) {

		var dzu_id = id.replace('dropzone_','');
		$('#dropzone_up_'+dzu_id).css('display','block');
		$('#dropzone_btn_'+dzu_id+' button').prop('disabled',true);

		var formData = new FormData();
		for (var i = 0; i < files.length; i++) {
			formData.append('update_image[]', files[i]);
		}
		//var tnum = id.replace('dropzone_tab','');
		var bname = $('#'+dzu_id).attr('class').replace(/ /gi,'').replace(/maxeditor/gi,'');
//console.log(bname);
		formData.append('bname', bname);

		//formData.append('imagepath', '/Bimages/201807');

		var url = direct + "/MaxEditor/ajax_imgupload_exec.php";
		$.ajax({
			url: url,
			type: 'POST',
			data: formData,
			dataType: 'text',
			processData: false,
			contentType: false,
			success: function(res) {
				$('#dropzone_up_'+dzu_id).css('display','none');
				$('#dropzone_btn_'+dzu_id+' button').prop('disabled',false);
				//console.log('success : ');
				//console.log(res);
				//FileMultiUpload_Callback(res.files);
				FileMultiUpload_Callback(res, id);
			},
			error:function(xhR,textStatus){
				$('#dropzone_up_'+dzu_id).css('display','none');
				$('#dropzone_btn_'+dzu_id+' button').prop('disabled',false);
				//console.log('xhr : ');
				//console.log(xhr);
				//console.log('textStatus : ');
				//console.log(textStatus);
				return;
			}
		});
	//}
}

/*
function drag(target, e) {
	e.dataTransfer.setData('Text', target.id);  // 발생한이벤트 정보를 dataTransfer 에 저장
};
function drop(target, e) {
	var data = e.dataTransfer.getData('Text');    // dataTransfer 에 저장된 데이터를 불러온다.
	console.log(target.id);
	console.log(data);
	//target.appendChild(document.getElementById(data));
	//target.after(document.getElementById(data));
	//$('#'+target.id).after(document.getElementById(data));
	//$(target).insertAfter(document.getElementById(data));
	//$('#'+data).insertAfter(document.getElementById(target.id));
	$('#'+data).after($('#'+target.id));
	e.preventDefault();        // 이벤트발생후 브라우저의 동작을 막는다.(스크롤이 위로올라가는등의)
};
*/
var id_leftA = new Array();

// 파일 멀티 업로드 Callback
function FileMultiUpload_Callback(files, id) {
	/*
	for(var i=0; i < files.length; i++)
	console.log(files[i].file_nm + " - " + files[i].file_size);
	*/
	//console.log(files);

	var tmp = files.split('|*|');
	if (tmp[1] == 'ok') {
		var tmp2 = tmp[2].split('|'); //원본파일명
		var tmp3 = tmp[3].split('|'); //업로드파일명
		if (tmp2.length > 2) {
			for (var tf=1; tf < tmp2.length-1; tf++) {
				if (tmp2[tf] != '' && tmp2[tf] != 'undefined') {
					if ($('#'+id).html() == title_drag_and_drop_image) {
						$('#'+id).html("<div class='tmp_blank_tnales' id='tbt_"+id+"_0' ondrop='drop(this, event);' ondragenter='return false;' ondragover='return false;'></div>").css('text-align','left');
					}

					var tmp3D = tmp3[tf].replace(/Bimages/gi,"Dimages");
					var tmp_ttid = tmp3[tf].split('/');
					var ttid = tmp_ttid[tmp_ttid.length-1];
					id_leftA[ttid] = tmp3[tf].replace(new RegExp(ttid,"gi"),"");

					var tmp_tnales = "<div class='tmp_tnales' id='tmp_tnales_"+ttid+"' style='background:url("+direct+tmp3D+") center center;background-size:cover;'><div class='tmp_tnales_del'><img src='"+direct+"/MaxEditor/img/x2.png'></div><div class='tmp_tnales_title'>"+tmp2[tf]+"</div></div>";

					$('#'+id).append(tmp_tnales);
				}
			}
		}

		var error_noti = "";
		var tmp4 = tmp[4].split('-');
		var tmp5 = tmp[5].split('-');
		var tmp6 = tmp[6].split('-');

		if (tmp4[0] != '0') error_noti += warn_image1 + tmp4[1] + warn_image2 + tmp4[0] + warn_image3;
		if (tmp5[0] != '0') error_noti += warn_image4 + tmp5[1] + warn_image5 + tmp5[0] + warn_image3;
		if (tmp6[0] != '0') error_noti += warn_image6 + tmp6[1].replace(/\|/gi,',') + warn_image7 + tmp6[0] + warn_image3;

		if (error_noti != '') {
			error_noti += warn_image8;
			alert (error_noti);
		}

		$('.dropzone').sortable();
	}
	else if (tmp[1] == 'noPermit'){
		var this_id = id.replace('dropzone_','');
		me_showhide_imgwin(this_id,'close');
		alert (alert_image2);
	}
}

$(document).on('click','.tmp_tnales_del',function(){
	$(this).parent().remove();
});

var sDefTxt = new Array();

function get_editor(id) {
	var url = direct + "/MaxEditor/ajax_get_editor.html";

    jQuery.ajaxSettings.traditional = true;
    $.post(
        url,
        {
			eid:id,
			lang:me_lang
		},
        function (data) {//console.log(data);
            if (data != '' && data != 'undefined') {
				var tmp = data.split("|*|");
				maxeditor(id, tmp[0]);	//에디터를 성공적으로 가져왔으면 해당텍스트위에 에디터를 붙인다
				size_full = tmp[1];
				size_normal = tmp[2];
				setmode_editor = tmp[3];
				setmode_code = tmp[4];
				title_drag_and_drop_image = tmp[5];
				alert_image1 = tmp[6];
				alert_image2 = tmp[7];
				warn_image1 = tmp[8];
				warn_image2 = tmp[9];
				warn_image3 = tmp[10];
				warn_image4 = tmp[11];
				warn_image5 = tmp[12];
				warn_image6 = tmp[13];
				warn_image7 = tmp[14];
				warn_image8 = tmp[15];
			}
			else $('.maxeditor').attr('contentEditable',false);
        }
    );

}

var buffer_ew = new Array();

function maxeditor(id, edtr) {

	var editor_id = "me_" + id; //에디터의 아이디를 만든다.
	var editor_ex_id = "ex_" + id; //에디터 확장버튼 아이디를 만든다.
	var editor_w = parseInt($('#'+id).css('width').replace(/px/gi,'')); //해당텍스트박스의 가로크기를 구한다. 이 사이즈를 에디터에 적용
	var editor_h = parseInt($('#'+id).css('height').replace(/px/gi,'')); //해당텍스트박스의 세로크기를 구한다. 이 사이즈를 에디터에 적용

	sDefTxt[id] = $('#'+id).html();
	if ($('#switchbox_'+id).is(':checked') == true) { setDocMode(id,true); }

	var editor_box = "<div class='me_editor_box' id='"+editor_id+"'>";
	editor_box += edtr;
	editor_box += "</div>";

	$('.maxeditor').attr('contentEditable',true).css('border','1px solid #cacaca').css('padding',text_padding + 'px').wrap('<div></div>');

	var editor_expander = "<div class='me_toolBar2' id='"+editor_ex_id+"' style='text-align:center;line-height:10px;'><font style='cursor:pointer;font-size:10px;' onclick=\"expander('"+id+"','shrink')\">▲</font> <font style='cursor:pointer;font-size:10px;' onclick=\"expander('"+id+"','expand')\">▼</font></div>";



	$('#'+id).before(editor_box); //해당텍스트박스의 상단에 에디터를 붙인다.
	$('#'+id).after(editor_expander); //해당텍스트박스의 하단에 확장축소버튼을 붙인다.

//alert ('A:' + editor_w);
	buffer_ew[id] = editor_w; //버퍼에 가로크기 저장

	//$('#'+editor_id).css('width',(editor_w - (text_padding * 2) - 2) + 'px').css('border','1px solid #cacaca').css('border-bottom','0 none #ffffff').css('margin-bottom','0').css('background-color',editor_bgcolor).css('padding',text_padding + 'px').css('border-top-left-radius',editor_radius+'px').css('border-top-right-radius',editor_radius+'px');

	//$('#'+editor_ex_id).css('width',(editor_w - (text_padding * 2) - 2) + 'px').css('border','1px solid #cacaca').css('border-top','0 none #ffffff').css('background-color',editor_bgcolor).css('text-align','center').css('padding','1px ' + text_padding + 'px').css('margin','0 0 20px 0').css('border-bottom-left-radius',editor_radius + 'px').css('border-bottom-right-radius',editor_radius + 'px');

	$('#'+editor_id).css('border','1px solid #cacaca').css('border-bottom','0 none #ffffff').css('margin-bottom','0').css('background-color',editor_bgcolor).css('padding',text_padding + 'px').css('border-top-left-radius',editor_radius+'px').css('border-top-right-radius',editor_radius+'px');

	$('#'+editor_ex_id).css('border','1px solid #cacaca').css('border-top','0 none #ffffff').css('background-color',editor_bgcolor).css('text-align','center').css('padding','1px ' + text_padding + 'px').css('margin','0 0 20px 0').css('border-bottom-left-radius',editor_radius + 'px').css('border-bottom-right-radius',editor_radius + 'px');

	$('img.me_eraser').prop('src',direct+'/MaxEditor/img/eraser.png');
	$('img.me_print').prop('src',direct+'/MaxEditor/img/print.png');
	$('img.me_undo').prop('src',direct+'/MaxEditor/img/prev.png');
	$('img.me_redo').prop('src',direct+'/MaxEditor/img/next.png');
	$('img.me_align_left').prop('src',direct+'/MaxEditor/img/align-left.png');
	$('img.me_align_center').prop('src',direct+'/MaxEditor/img/align-center.png');
	$('img.me_align_justify').prop('src',direct+'/MaxEditor/img/align-justify.png');
	$('img.me_align_right').prop('src',direct+'/MaxEditor/img/align-right.png');
	$('img.me_list_numbers').prop('src',direct+'/MaxEditor/img/list-number.png');
	$('img.me_list_dots').prop('src',direct+'/MaxEditor/img/list-dots.png');
	$('img.me_blockquote').prop('src',direct+'/MaxEditor/img/blockquote.png');
	$('img.me_reduce_indent').prop('src',direct+'/MaxEditor/img/indent-reduce.png');
	$('img.me_indent').prop('src',direct+'/MaxEditor/img/indent.png');
	$('img.me_hyperlink').prop('src',direct+'/MaxEditor/img/link-button.png');
	$('img.me_cut').prop('src',direct+'/MaxEditor/img/cut.png');
	$('img.me_copy').prop('src',direct+'/MaxEditor/img/copy.png');
	$('img.me_paste').prop('src',direct+'/MaxEditor/img/paste.png');
	$('img.me_chg_editor_size').prop('src',direct+'/MaxEditor/img/size-full.png');
	$('img.me_table').prop('src',direct+'/MaxEditor/img/table.png');
	$('img.me_image').prop('src',direct+'/MaxEditor/img/photo.png');
	$('img.color_wheel').prop('src',direct+'/MaxEditor/img/colorwheel.jpg');

	var dropzone_w = editor_w - 50; //마진,패딩값제거
	var editor_box_h = parseInt($('#'+editor_id).css('height').replace(/px/gi,'')) + 15;
	$('#search_img_'+id).css('width',dropzone_w + 'px').css('top',editor_box_h + 'px');
	$('#dropzone_'+id).css('width',dropzone_w + 'px').css('top',(editor_box_h + 30) + 'px');
	$('.dropzone_up img').prop('src',direct+'/MaxEditor/img/loading1.gif');
	$('#dropzone_up_'+id).css('top',(editor_box_h + 10) + 'px');
	$('.dropzone_btn').css('top',editor_box_h + 'px');

	//$('#sourceText_'+id).css('width',editor_w + 'px').css('overflow','auto');

	//me_chg_size();
	me_chg_size_run(id);
}

function expander(id,a) {
	var editor_h = parseInt($('#'+id).css('height').replace(/px/gi,''));
	if (a == 'expand') {
		editor_nh = editor_h + 300;
	}
	else if (a == 'shrink') {
		if (editor_h > 300) editor_nh = editor_h - 300;
		else editor_nh = editor_h;
	}
	//console.log(id + ' , ' + a + ' , ' + editor_nh);
/*
	$('#'+id).animate({'height':editor_nh + 'px'},100,function() {console.log('changed');
		me_chg_size();
	});
	*/
	$('#'+id).css('height',editor_nh + 'px');

	me_chg_size_run(id);
}

function me_chg_size() {//alert ('me_chg_size');
	$('.maxeditor').each(function(index) {
		var this_id = $(this).attr('id'); //텍스트박스의 아이디를 추출해낸다
		if (this_id) {
			me_chg_size_run(this_id);
			//$('#sourceText_'+this_id).css('width',editor_w + 'px').css('overflow','auto');
		}
	});
}

var saveWidth = new Array();
var saveHeight = new Array();
var fullsizeA = new Array();
var fullsized_id;
var ori_width_type = new Array();

function set_size(id) {
	$('#'+id).css('width',saveWidth[id] + 'px');
}

function me_chg_size_run(this_id,opt) {//alert ('me_chg_size_run : ' + this_id + ' : ' + opt);
	var editor_id = "me_" + this_id; //에디터의 아이디를 만든다.
	var editor_ex_id = "ex_" + this_id; //에디터 확장버튼 아이디를 만든다.
	if (opt && saveWidth[this_id]) {
		var editor_w = saveWidth[this_id]; //해당텍스트박스의 원래가로크기를 구한다. 이 사이즈를 에디터에 적용
		//alert ("1 - " + opt + " : " + buffer_ew[this_id]);
	}
	else {
		var editor_w = parseInt($('#'+this_id).css('width').replace(/px/gi,'')); //해당텍스트박스의 가로크기를 구한다. 이 사이즈를 에디터에 적용
		//alert ("2 - " + editor_w);
	}
	var editor_h = parseInt($('#'+this_id).css('height').replace(/px/gi,'')); //해당텍스트박스의 세로크기를 구한다.
	if (fullsizeA[this_id] != 'full') {
		saveWidth[this_id] = editor_w;
		saveHeight[this_id] = editor_h; //console.log(editor_w + " : " + editor_h);
	}
//alert ('B:' + editor_w + " , opt:" + opt);
	//if (opt && editor_w == buffer_ew[this_id]) {
	//	$('#'+editor_id).css('width',(editor_w - (text_padding * 2) - 2) + 'px');
	//	$('#'+editor_ex_id).css('width',(editor_w - (text_padding * 2) - 2) + 'px');
	//}
	//else {
		//$('#'+editor_id).css('width',editor_w + 'px');
		//$('#'+editor_ex_id).css('width',editor_w + 'px');
	//}

	var dropzone_w = editor_w - (15 * 2) - 4; //패딩,보더값제거
	var dropzone_h = editor_h - 50 - 25 - 30; //마진,패딩값,서치박스값 제거
	var editor_box_h = parseInt($('#'+editor_id).css('height').replace(/px/gi,'')) + 9 + (text_padding * 2);
	var dropzone_up_w = parseInt($('#dropzone_up_'+this_id).css('width').replace(/px/gi,''));
	var dropzone_up_h = parseInt($('#dropzone_up_'+this_id).css('height').replace(/px/gi,''));
	var dropzone_up_t = ((dropzone_h - dropzone_up_h) / 2) + 35;
	var dropzone_up_l = (dropzone_w - dropzone_up_w) / 2;
	$('#search_img_'+this_id).css('width',dropzone_w + 'px').css('top',editor_box_h + 'px');
	$('#dropzone_'+this_id).css('width',dropzone_w + 'px').css('top',(editor_box_h + 34) + 'px').css('height',dropzone_h + 'px');
	$('#dropzone_up_'+this_id).css('top',(editor_box_h + dropzone_up_t) + 'px').css('left',dropzone_up_l + 'px');
	$('#dropzone_btn_'+this_id).css('width',(editor_w + text_padding * 2) + 'px').css('top',(editor_box_h - text_padding + 1) +'px').css('padding-top',(editor_h - 15) + 'px');
	//console.log('mcsr:' + $('#'+this_id).width());

	$('#ins_table_'+this_id).css('top',(editor_box_h - 9) + 'px').css('left',((editor_w - 480) / 2) + 'px');
}

$(window).resize(me_chg_size);
$(window).resize(function() {
	me_chg_editor_size(null);
});

var adm_main_btn_ = "";

function me_chg_editor_size(tid) {
	//console.log('mces : ' + tid + " : "  + fullsized_id);
	//console.log(tid);

	if (tid == null && fullsized_id) {
		var tid = fullsized_id;
		//console.log('B : ' + tid);
	}
	else if (tid){
		if (fullsizeA[tid] != 'full') fullsizeA[tid] = 'full';
		else fullsizeA[tid] = 'normal';
		fullsized_id = tid;
		//console.log('A : ' + tid + ' : ' + fullsizeA[tid]);
	}

	if (fullsizeA[tid] == 'full') { //console.log('C : ');
		/*
		var gg = 0;
		$('body').('class').each(function(index) {
			console.log(gg);
			gg++;
		});
		*/

		if ($('.adm_main_btn_left').css('display') != 'none') adm_main_btn = 'opened';
		else adm_main_btn = 'closed';

		$('.adm_header').css({'display':'none'});
		$('.adm_main_tab_left').css({'display':'none'});
		$('.adm_main_btn_left').css({'display':'none'});
		$('.adm_main_btn_right').css({'display':'none'});
		$('.adm_footer').css({'display':'none'});

		var editor_w = parseInt($('#'+tid).css('width').replace(/px/gi,'')); //해당텍스트박스의 가로크기를 구한다. 이 사이즈를 에디터에 적용
		buffer_ew[tid] = editor_w; //버퍼에 가로크기 저장
//alert ("C: " + editor_w);
		if (!ori_width_type[tid]) {
			ori_width_type[tid] = getStyle(document.getElementById(tid));
			//console.log(getStyle(document.getElementById(tid)));
		}

		if (document.body && document.body.offsetWidth) {
			var width = document.body.clientWidth;
			var height = document.body.clientHeight;
		}
		if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
			var width = document.documentElement.clientWidth;
			var height = document.documentElement.clientHeight;
		}
		if (window.innerWidth && window.innerHeight) {
			var width = window.innerWidth;
			var height = window.innerHeight;
			//var width = $('body').innerWidth();
			//var height = $('body').innerHeight();
		}

		$('#editor_size_'+tid).prop('title',size_normal).prop('src',direct+'/MaxEditor/img/size-normal.png');

		$('html,body').css('overflow','hidden');

		var editor_id = "me_" + tid; //에디터의 아이디를 만든다.
		var editor_ex_id = "ex_" + tid; //에디터 확장버튼 아이디를 만든다.

		if ($('#me_'+tid).parent().attr('class') != 'me_fullsize') {
			$('#'+editor_id).wrap("<div class='me_fullsize'></div>").parent().next().appendTo($('#'+editor_id).parent());
		}

		zidx++;

		$('.me_fullsize').css('position','fixed').css('top','0').css('left','0').css('width',width+'px').css('height',height+'px').css('z-index',zidx).css('overflow','hidden');

		var id_width = parseInt($('.me_fullsize').css('width').replace(/px/gi,'')) - (text_padding * 2) - 2;

		$('#'+tid).css('width',id_width + 'px');
		//$('#'+editor_id).css('width',id_width + 'px');
		$('#'+editor_ex_id).css('display','none');

		var id_height = height - parseInt($('#'+editor_id).css('height').replace(/px/gi,'')) - (text_padding * 4) - 2;
		$('#'+tid).css('height',id_height + 'px');

		var dropzone_w = id_width - (15 * 2) - 4; //패딩,보더값제거
		var dropzone_h = id_height - 50 - 25 - 30; //마진,패딩값,서치박스값 제거
		var editor_box_h = parseInt($('#'+editor_id).css('height').replace(/px/gi,'')) + 9 + (text_padding * 2);
		var dropzone_up_w = parseInt($('#dropzone_up_'+tid).css('width').replace(/px/gi,''));
		var dropzone_up_h = parseInt($('#dropzone_up_'+tid).css('height').replace(/px/gi,''));
		var dropzone_up_t = ((dropzone_h - dropzone_up_h) / 2) + 35;
		var dropzone_up_l = (dropzone_w - dropzone_up_w) / 2;
		$('#search_img_'+tid).css('width',dropzone_w + 'px').css('top',editor_box_h + 'px');
		$('#dropzone_'+tid).css('width',dropzone_w + 'px').css('top',(editor_box_h + 34) + 'px').css('height',dropzone_h + 'px');
		$('#dropzone_up_'+tid).css('top',(editor_box_h + dropzone_up_t) + 'px').css('left',dropzone_up_l + 'px');
		$('#dropzone_btn_'+tid).css('width',(id_width + text_padding * 2) + 'px').css('top',(editor_box_h - text_padding + 1) +'px').css('padding-top',(id_height - 15) + 'px');

		//console.log(width + ' , ' + $('.me_fullsize').css('width') + ' , ' + $('#'+tid).css('width'));
	}
	else if (fullsizeA[tid] == 'normal') { //console.log('D : ');
		$('.adm_header').css({'display':'block'});
		if (adm_main_btn == 'opened') {
			$('.adm_main_tab_left').css({'display':'block'});
			$('.adm_main_btn_left').css({'display':'block'});
		}
		else {
			$('.adm_main_tab_left').css({'display':'none'});
			$('.adm_main_btn_right').css({'display':'block'});
		}
		$('.adm_footer').css({'display':'block'});

		if ($('#me_'+tid).parent().attr('class') == 'me_fullsize') {
			$('html,body').css('overflow','auto');
			$('#editor_size_'+tid).prop('title',size_full).prop('src',direct+'/MaxEditor/img/size-full.png');
			$('#me_'+tid).unwrap();
			if (ori_width_type[tid] == 'auto') {
				$('#'+tid).css('width',saveWidth[tid] + 'px').css('height',saveHeight[tid]);
				//console.log('1auto');
				$('#'+tid).css('width','');
			}
			else if (ori_width_type[tid].indexOf('%') != -1){
				$('#'+tid).css('width',ori_width_type[tid]).css('height',saveHeight[tid]);
				//console.log('2%');
			}
			else {
				$('#'+tid).css('width',saveWidth[tid] + 'px').css('height',saveHeight[tid]);
				//console.log('3px');
			}
			$('#ex_'+tid).css('display','block');
			me_chg_size_run(tid,'toNormal');
		}
	}
}

//width가 퍼센트인지 픽셀인지 확인
function getStyle(el){
    var display = window.getComputedStyle(el).getPropertyValue("display");
    el.style.display = "none";
    var width = window.getComputedStyle(el).getPropertyValue("width");
    el.style.display = display;
    return width;
}

function insert_table(id) {
	var t_cols = $('#'+ id + '_tab_cols').val();
	var t_rows = $('#'+ id + '_tab_rows').val();
	var t_width = $('#'+ id + '_tab_width').val();
	var t_width_stand = $('#'+ id + '_tab_width_stand').val();
	var t_height = $('#'+ id + '_tab_height').val();
	var t_height_stand = $('#'+ id + '_tab_height_stand').val();
	var t_cellpadding = $('#'+ id + '_tab_cellpadding').val();
	var t_cellspacing = $('#'+ id + '_tab_cellspacing').val();
	var t_border_width = $('#'+ id + '_tab_border_width').val();
	var t_border_style = $('#'+ id + '_tab_border_style').val();
	var t_border_color = $('#'+ id + '_tab_border_color').val();
	var t_background_color = $('#'+ id + '_tab_background_color').val();
	var t_align = $('#'+ id + '_tab_align').val();
	var t_valign = $('#'+ id + '_tab_valign').val();
	var t_header = $('#'+ id + '_tab_header').val();
	var t_caption = $('#'+ id + '_tab_caption').val();
	var t_summary = $('#'+ id + '_tab_summary').val();
	var t_class = $('#'+ id + '_tab_class').val();
	var t_id = $('#'+ id + '_tab_id').val();

	if (t_cols == '' || t_cols == '0' || isNaN(t_cols)) {
		if (me_lang == "ko") alert ('칸 수를 숫자로 입력해주세요.');
		else if (me_lang == "en") alert ('Please enter numeric value in the Columns');
	}
	else if (parseInt(t_cols) < 1 || parseInt(t_cols) > 50) {
		if (me_lang == "ko") alert ('1 ~ 50 사이의 숫자로 입력해주세요.');
		else if (me_lang == "en") alert ('Please enter number between 1 and 50 in the Columns');
	}
	else if (t_rows == '' || t_rows == '0' || isNaN(t_rows)) {
		if (me_lang == "ko") alert ('줄 수를 숫자로 입력해주세요.');
		else if (me_lang == "en") alert ('Please enter numeric value in the Rows');
	}
	else if (parseInt(t_rows) < 1 || parseInt(t_rows) > 100) {
		if (me_lang == "ko") alert ('1 ~ 100 사이의 숫자로 입력해주세요.');
		else if (me_lang == "en") alert ('Please enter number between 1 and 100 in the Rows');
	}
	else {
		var table_form = "<table cellpadding='" + t_cellpadding + "' cellspacing='" + t_cellspacing + "' ";

		if (parseInt(t_border_width) > 0 && parseInt(t_cellspacing) == 0) table_form += "border='1'"
		else table_form += "border='0'";

		table_form += " style='";

		if (parseInt(t_border_width) > 0 && parseInt(t_cellspacing) == 0) table_form += "border-collapse:collapse;";

		table_form += "width:" + parseInt(t_width) + t_width_stand + ";";

		if (parseInt(t_height) > 0) table_form += " height:" +  + parseInt(t_height) + t_height_stand + ";";

		if (t_background_color != '') table_form += " background-color:" + t_background_color + ";";

		table_form += " border-color:" + t_border_color + "; border-width:" + parseInt(t_border_width) + "px; border-style:" + t_border_style + ";'";

		if (t_class != '') table_form += " class='" + t_class + "'";
		if (t_id != '') table_form += " id='" + t_id + "'";

		if (t_summary != '') table_form += " summary='" + t_summary + "'";

		table_form += ">";

		if (t_caption != '') table_form += "<caption>" + t_caption + "</caption>";

		table_form += "<tbody>";

		var thd_border = " border:" + parseInt(t_border_width) + "px " + t_border_style + " " + t_border_color + ";";

		for (var r=1; r <= parseInt(t_rows); r++) {
			table_form += "<tr>";
			for (var c=1; c <= parseInt(t_cols); c++) {
				var thd = "style='" + thd_border + " text-align:" + t_align + "; vertical-align:" + t_valign + "; padding:" + t_cellpadding + "px;'";
				if (t_header == 'none') {
					table_form += "<td " + thd + ">&nbsp;</td>";
				}
				else if (t_header == 'row') {
					if (r == 1) table_form += "<th " + thd + ">&nbsp;</th>";
					else table_form += "<td " + thd + ">&nbsp;</td>";
				}
				else if (t_header == 'col') {
					if (c == 1) table_form += "<th " + thd + ">&nbsp;</th>";
					else table_form += "<td " + thd + ">&nbsp;</td>";
				}
				else if (t_header == 'all') {
					if (r == 1 || c == 1) table_form += "<th " + thd + ">&nbsp;</th>";
					else table_form += "<td " + thd + ">&nbsp;</td>";
				}
			}
			table_form += "</tr>";
		}

		table_form += "</tbody></table>"; //console.log(table_form);

		restoreSelection(id);

		formatDoc(id, 'insertHTML', table_form);

		me_showhide_tablewin(id);
	}
}

function insert_imgs(id) {
	var cnt_imgs = 0;

	if (browser != 'ie10' && browser != 'ie11' && browser != 'edge') {
		$('#dropzone_'+id).children('.tmp_tnales').each(function(index) {
			cnt_imgs++;
			var this_id = $(this).attr('id');
			var fn = this_id.replace("tmp_tnales_","");
			var img_src = direct + id_leftA[fn] + fn; //console.log("img_src"+img_src);
			setTimeout(function(){
				formatDoc(id, 'insertImage', img_src);
			},0 + ( cnt_imgs * 500 ));
		});
	}
	else {
		$($('#dropzone_'+id).children('.tmp_tnales').get().reverse()).each(function(index) {
			cnt_imgs++;
			var this_id = $(this).attr('id');
			var fn = this_id.replace("tmp_tnales_","");
			var img_src = direct + id_leftA[fn] + fn; //console.log("img_src"+img_src);
			setTimeout(function(){
				formatDoc(id, 'insertImage', img_src);
			},0 + ( cnt_imgs * 500 ));
		});
	}

	if (cnt_imgs == 0) alert(alert_image1);

	me_showhide_imgwin(id);
}

function me_showhide_submenu(id,a,force_out) {

	$('.ins_table').css('display','none');
	$('#me_table_'+id).parent().css('background-color','transparent');

	$('#search_img_'+id).css('display','none');
	$('#dropzone_'+id).css('display','none').html(title_drag_and_drop_image).css('text-align','center');
	$('#dropzone_btn_'+id).css('display','none');
	$('#me_image_'+id).parent().css('background-color','transparent');

	if (force_out) {
		$('.me_toolBar1 div ul').css('display','none');
	}
	else {
		if ($('.'+a+'_'+id+' ul').css('display') != 'none') var me_sub_menu_on = 1;
		else var me_sub_menu_on = 0;
		$('.me_toolBar1 div ul').css('display','none');
		if (me_sub_menu_on == 0) {
			zidx++;
			$('.'+a+'_'+id).css('z-index',zidx);
			$('.'+a+'_'+id+' ul').css('display','block');
		}
	}
}

function me_showhide_tablewin(id,force) {

	me_chg_size();

	$('.me_toolBar1 div ul').css('display','none');
	$('#search_img_'+id).css('display','none');
	$('#dropzone_'+id).css('display','none').html(title_drag_and_drop_image).css('text-align','center');
	$('#dropzone_btn_'+id).css('display','none');
	$('#me_image_'+id).parent().css('background-color','transparent');

	if (force && force == 'open') {//console.log(1);
		$('#ins_table_'+id).fadeIn();
		$('#me_table_'+id).parent().css('background-color','#cee0f0');
	}
	else if (force && force == 'close') {//console.log(id);
		$('#ins_table_'+id).css('display','none');
		$('#'+id).focus();
		restoreSelection('tablewin_close');
		$('#me_table_'+id).parent().css('background-color','transparent');
	}
	else {//console.log(3);
		if ($('#ins_table_'+id).css('display') != 'none') var me_tablewin_on = 1;
		else var me_tablewin_on = 0;
		$('.ins_table').css('display','none');
		if (me_tablewin_on == 0) {
			saveSelection('insertHTML', id);
			$('#ins_table_'+id).fadeIn();
			$('#me_table_'+id).parent().css('background-color','#cee0f0');
		}
		else {
			$('#'+id).focus();
			restoreSelection('tablewin_close');
			$('#me_table_'+id).parent().css('background-color','transparent');
		}
	}
}

function me_showhide_table_color(id,a,force_out) {
	if (force_out) {
		$('.td_color ul').css('display','none');
	}
	else {
		if ($('#'+id+'_'+a).parent().children('ul').css('display') != 'none') var me_color = 1;
		else var me_color = 0;

		if (me_color == 0) {
			zidx++;
			$('#'+id+'_'+a).parent().css('z-index',zidx);
			$('.td_color ul').css('display','none');
			$('#'+id+'_'+a).parent().children('ul').css('display','block');
		}
		else {
			$('#'+id+'_'+a).parent().children('ul').css('display','none');
		}
	}
}

function me_showhide_imgwin(id,force) {
	me_chg_size();

	$('.me_toolBar1 div ul').css('display','none');
	$('.ins_table').css('display','none');
	$('#me_table_'+id).parent().css('background-color','transparent');

	if (force && force == 'open') {//console.log(1);
		$('#search_img_'+id).fadeIn();
		$('#dropzone_'+id).fadeIn();
		$('#dropzone_btn_'+id).fadeIn();
		$('#me_image_'+id).parent().css('background-color','#cee0f0');
	}
	else if (force && force == 'close') {//console.log(id);
		$('#search_img_'+id).css('display','none');
		$('#dropzone_'+id).css('display','none').html(title_drag_and_drop_image).css('text-align','center');
		$('#dropzone_btn_'+id).css('display','none');
		$('#me_image_'+id).parent().css('background-color','transparent');
	}
	else {//console.log(3);
		if ($('#dropzone_'+id).css('display') != 'none') var me_imgwin_on = 1;
		else var me_imgwin_on = 0;
		$('.search_img').css('display','none');
		$('.dropzone').css('display','none').html(title_drag_and_drop_image).css('text-align','center');
		$('.dropzone_btn').css('display','none');
		if (me_imgwin_on == 0) {
			$('#search_img_'+id).fadeIn();
			$('#dropzone_'+id).fadeIn();
			$('#dropzone_btn_'+id).fadeIn();
			$('#me_image_'+id).parent().css('background-color','#cee0f0');
		}
		else {
			$('#'+id).focus();
			restoreSelection(id);
			$('#me_image_'+id).parent().css('background-color','transparent');
		}
	}
}

function confirm_validateMode(id) {
	if (id) {
		$('#'+id).html(sDefTxt[id]);
	}
	else {
		$('.maxeditor').each(function(index) {
			var this_id = $(this).attr('id');
			$('#'+this_id).html(sDefTxt[this_id]);
		});
	}
}

if (browser == 'ie10' || browser == 'ie11' || browser == 'edge') {
	//$(document).on('mousedown','.maxeditor',function(){ return cancelEvent(event); });
	//$(document).on('click','.maxeditor',function(){ return cancelEvent(event); });
	//$(document).on('blur','.maxeditor',function(){ saveSelection('blur'); });
	$(document).on('mouseup','.maxeditor',function(){ saveSelection('mouseup'); });
	$(document).on('keyup','.maxeditor',function(){ saveSelection('keyup'); });
	$(document).on('focus','.maxeditor',function(){ restoreSelection(this); });
}

var savedRange, isInFocus;

function saveSelection(a, id) {
	//if (browser == 'ie10' || browser == 'ie11' || browser == 'edge') {
		if (a) var aa = a + " ";
		else aa = '';
		if(window.getSelection) {//non IE Browsers
			if (a && a == 'insertImage') {
				//window.getSelection().addRange(savedRange);
				//window.getSelection().selectRange(2);
				//var cursorPos = getTextCursorPosition($('#'+id));
				//console.log(aa+cursorPos);
			}
			savedRange = window.getSelection().getRangeAt(0);
			//console.log(aa+'save');
			//console.log(savedRange);
		}
		else if(document.selection) {//IE
			savedRange = document.selection.createRange();
			//console.log(aa+'save1');
			//console.log(savedRange);
		}
	//}
	//console.log(savedRange);
}

var agent = navigator.userAgent.toLowerCase();

function restoreSelection(id) {
	isInFocus = true;
	//var this_id = $(id).attr('id');
	//$('#'+this_id).focus();
	if (savedRange != null) {
		if (savedRange.rangeCount > 0) { //non IE and there is already a selection
			savedRange.removeAllRanges();
			//console.log('removeAllRanges');
		}
		if (document.createRange) {//non IE and no selection
			window.getSelection().removeAllRanges();
			if ((navigator.appName == 'Netscape' && agent.indexOf('trident') != -1) || (agent.indexOf("msie") != -1)) {
				//savedRange.collapse(false);
				//console.log('ie');
//				console.log(savedRange);
//				window.getSelection().setStart(savedRange,savedRange.startOffset+1);
//				window.getSelection().setEnd(savedRange,savedRange.endOffset+1);
//				document.selection.createRange().moveStart(savedRange,1);
				//console.log(savedRange);
			}
			window.getSelection().addRange(savedRange);
			//console.log('restore2');
		}
		else if (window.getSelection) {
			var s = window.getSelection();
			s.addRange(savedRange);
			//console.log('restore3');
		}
		else if (document.selection) {//IE
			savedRange.collapse(false);
			savedRange.select();
			//console.log('restore1');
		}
	}
}

var isInFocus = false;
function onDivBlur() {
    isInFocus = false;
}

function cancelEvent(e) {
    if (isInFocus == false && savedRange != null) {
        if (e && e.preventDefault) {
            //alert("FF");
            e.stopPropagation(); // DOM style (return false doesn't always work in FF)
            e.preventDefault();
        }
        else {
            window.event.cancelBubble = true;//IE stopPropagation
        }
        restoreSelection();
        return false; // false = IE style
    }
}

function formatDoc(id, sCmd, sValue) {
	//$('#'+id).focus();
	if (validateMode(id)) {
		if (sCmd != 'insertHTML') {
			document.execCommand(sCmd, false, sValue);console.log(sCmd);
		}
		else {
			if (browser.indexOf('ie') != -1 && window.getSelection) {
				savedRange.deleteContents();
				savedRange.insertNode(savedRange.createContextualFragment(sValue));
			}
			else if (document.selection) {
				savedRange.select();
				savedRange.pasteHTML(sValue);
			}
			else {
				document.execCommand(sCmd, false, sValue);
			}

		}
		//restoreSelection();
		$('#'+id).focus();
		//saveSelection();
		//$('#'+id).focus();
	}
}

function validateMode(id) {
	if ($('#switchbox_'+id).is(':checked') == false) { return true ; }
	alert("Uncheck \"Show HTML\".");
	$('#'+id).focus();
	return false;
}

function setDocMode(id) {

	if ($('#switchbox_'+id).is(":checked") == true) $('#switchbox_'+id).prop("checked",false);
	else $('#switchbox_'+id).prop("checked",true);

	var oContent;

	if ($('#switchbox_'+id).is(":checked") == true) { //console.log('code');
		$('#html_'+id).css({'background-color':'#b9ecec'},{'color':'#ffffff'}).html(setmode_editor);
		oContent = document.createTextNode($('#'+id).html());
		$('#'+id).html("");
		var oPre = document.createElement("div");
		$('#'+id).attr('contentEditable',false);
		oPre.id = "sourceText_"+id;
		oPre.className = "sourceText";
		oPre.contentEditable = true;
		oPre.appendChild(oContent);
		$('#'+id).html(oPre);
	}
	else {//console.log('edit');
		$('#html_'+id).css({'background-color':'#d2d2d2'},{'color':'#000000'}).html(setmode_code);
		if (document.all) {
			$('#'+id).html($('#'+id).text());
		}
		else {
			oContent = document.createRange();
			oContent.selectNodeContents(document.getElementById(id).firstChild);
			$('#'+id).html(oContent.toString());
		}
		$('#'+id).attr('contentEditable',true);
	}
	$('#'+id).focus();
	//me_chg_size_run(id);
}

function printDoc(id) {
	if (!validateMode()) { return; }
	var oPrntWin = window.open("","_blank","width=700,height=600,left=200,top=100,menubar=yes,toolbar=no,location=no,scrollbars=yes");
	oPrntWin.document.open();
	oPrntWin.document.write("<!doctype html><html><head><title>Print<\/title><\/head><body onload=\"print();\">" + $('#'+id).html() + "<\/body><\/html>");
	oPrntWin.document.close();
}

function pre_chk_data() { //내용을 넘기기위해 사전체크
	$('.maxeditor').each(function(index) {
		var this_id = $(this).attr('id'); //텍스트박스의 아이디를 추출해낸다
		if (this_id) {
			if ($('#switchbox_'+this_id).is(":checked") == true) setDocMode(this_id); //소스코드보기로 되어있는 것을 에디터보기로 변경

			if ($('#'+this_id).attr('alt')) { //타이틀이 존재하는 경우
				var inputname = $('#'+this_id).attr('alt'); //타이틀명을 찾는다 (실제 넘길 변수 이름임)
				$("input[name='"+inputname+"']").val($('#'+this_id).html()); //실제 넘길 변수에 내용 입력
			}
		}
	});
}