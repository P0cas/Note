<?php
session_start();
ini_set('memory_limit', '256M');
if ($_SESSION['mb_id'] == '' || $_POST['bname'] == '') {exit;}

### 기본 정보 가져오기 ###
$direct = "..";
include "$direct/global/options.html";
#################
//echo $Lvl_isAdA[$_SESSION['mb_level']] . " : " . $_SERVER['PHP_SELF'] . " : ";
///global/permitoption.html 에서 추출
if ($write_pass == 'no') {
	echo "|*|noPermit|*|";
	exit;
}

/*
print_r($_POST);
print_r($_FILES);
*/
//$upload_max_filesize = ini_get('upload_max_filesize');
$upload_max_filesize = $image_max_size;

$id = $_POST['id'];
//$imagepath = $_POST['imagepath'];
$imagepath = "/Bimages/" . $TNow_Y . $TNow_MM;
if ($_POST['tnum'] != '') $tnum = $_POST['tnum'];
//$tnum : 넘어온 tnum이 없다면 /global/permitoption.html 에서 추출
$tmpipath = explode ("/Bimages",$imagepath);
$imagepath = "Bimages" . $tmpipath[1];
//$imagepath = "../data/file/season{$id}";

@mkdir("$direct/$imagepath", 0707);
@chmod("$direct/$imagepath", 0707);

// 원본이미지용
$imagepathA = str_replace("Bimages","Aimages",$imagepath);
@mkdir("$direct/$imagepathA", 0707);
@chmod("$direct/$imagepathA", 0707);

// 썸네일용
$imagepathC = str_replace("Bimages","Ctnales",$imagepath);
@mkdir("$direct/$imagepathC", 0707);
@chmod("$direct/$imagepathC", 0707);

// 작은이미지2용
$imagepathD = str_replace("Bimages","Dimages",$imagepath);
@mkdir("$direct/$imagepathD", 0707);
@chmod("$direct/$imagepathD", 0707);

$chars_array = array_merge(range(0,9), range('a','z'), range('A','Z'));

$file_upload_msg = "";

function makeimage($stand_width,$stand_height,$logo='no',$string='',$font_locate,$font_size='24',$logocolor='white',$thePath) {

	global $dest_file,$tnum;

	$size = @getimagesize($dest_file);
	//list($foo,$width,$bar,$height) = explode("\"",$size[3]);

	//$imgThumb = $imgSource = $dest_file;
	$imgSource = $dest_file;
	$imgThumb = $thePath;

	if ($size[2] == 1) {
		$source = imagecreatefromgif($imgSource);
	}
	else if ($size[2] == 2) {
		ini_set("gd.jpeg_ignore_warning", 1);
		$source = imagecreatefromjpeg($imgSource);
	}
	else if ($size[2] == 3) {
		$source = imagecreatefrompng($imgSource);
	}
	else {
		return false;
	}

	## 기존값은 600 이지만 설정값에 맞게 수정하도록 변수로 대체함
	$rate = $stand_width / $size[0];
	$height = (int)($size[1] * $rate);

	if ($rate > 1) {
		$target = @imagecreatetruecolor($size[0], $size[1]);
		$width = $size[0];
		$height = $size[1];
	}
	else {
		$target = @imagecreatetruecolor($stand_width, $height);
		$width = $stand_width;
	}

	@imagealphablending($target, false);
	@imagesavealpha($target, true);

	@imagecopyresampled($target, $source, 0, 0, 0, 0, $width, $height, $size[0], $size[1]);

	### 로고가 있을 경우 적용 ###
	if ($logo == 'ok') {
			//$stringx = iconv("EUC-KR","UTF-8",$string);
			$stringx = $string;
			$stringlen = strlen($stringx);
			$halflen = floor(($font_size * $stringlen) / 2) - ($stringlen * 6);
			$x0=($width/2-$halflen) ;
			$y0=($height/2+$font_size/2) ;
			$font_file=$font_locate;

			$lc1 = 255;
			$lc2 = 255;
			$lc3 = 255;
			if ($logocolor == 'white') {$lc1 = 255; $lc2 = 255; $lc3 = 255;}
			elseif ($logocolor =='black') {$lc1 = 0; $lc2 = 0; $lc3 = 0;}
			elseif ($logocolor =='red') {$lc1 = 255; $lc2 = 0; $lc3 = 0;}
			elseif ($logocolor =='blue') {$lc1 = 0; $lc2 = 0; $lc3 = 255;}
			elseif ($logocolor =='green') {$lc1 = 0; $lc2 = 255; $lc3 = 0;}
			elseif ($logocolor =='yellow') {$lc1 = 255; $lc2 = 255; $lc3 = 0;}
			elseif ($logocolor =='silver') {$lc1 = 245; $lc2 = 245; $lc3 = 245;}
			elseif ($logocolor =='grey') {$lc1 = 162; $lc2 = 162; $lc3 = 162;}

			$back=ImageColorAllocate($source, 0x80, 0x80, 0x80);//배경의 컬러할당(회색)
			$pen_color=ImageColorAllocate($source,$lc1,$lc2,$lc3);//echo "<script>alert ('$font_size,0,$x0,$y0,$pen_color,$font_file,$string');</script>";
			//ImageTTFText($target,$font_size,0,$x0,$y0,$pen_color,$font_file, iconv("EUC-KR","UTF-8",$string));
			ImageTTFText($target,$font_size,0,$x0,$y0,$pen_color,$font_file, $stringx);
	}
	####################

	if ($size[2] == 1) {
		@imageGIF($target,$imgThumb,100);
	}
	else if ($size[2] == 2) {
		@imagejpeg($target, $imgThumb, 100);
	}
	else if ($size[2] == 3) {
		@imagePNG($target,$imgThumb,9);
	}
	else {
		@imagejpeg($target, $imgThumb, 100);
	}

	@chmod($imgThumb, 0606); // 추후 삭제를 위하여 파일모드 변경

	ImageDestroy($target);
	ImageDestroy($source);

	return Array($width,$height);
}

$buffx = "|";
$imgpath = "|";
$error_width = 0;
$error_size = 0;
$error_type = 0;
for ($k=0;$k<count($_FILES['update_image']['name']);$k++) {

	$tmp_file  = $_FILES['update_image']['tmp_name'][$k];
	$filename  = $_FILES['update_image']['name'][$k];
	$filesize  = $_FILES['update_image']['size'][$k];

	//이미지파일인지 확인
	$upfile = getimagesize($tmp_file);
	if (!is_numeric($upfile[0]) || $upfile[0] == 0 || $upfile[0] == null || !is_numeric($upfile[1]) || $upfile[1] == 0 || $upfile[1] == null || $upfile[2] < 1 || $upfile[2] > 3) {
		//이미지파일이 아니면 그냥 넘김
	}
	else {

		if (function_exists('exif_read_data')) {
			$exif = @exif_read_data($_FILES['update_image']['tmp_name'][$k]);
		}

		if (!strstr($buffx,"|".$filename."|")) {

			// 서버에 설정된 값보다 큰파일을 업로드 한다면
			/*
			if ($filename) {
				if ($_FILES['update_image']['error'][$k] == 1) {
					$file_upload_msg .= "\'{$filename}\' 파일의 용량이 서버에 설정($upload_max_filesize)된 값보다 크므로 업로드 할 수 없습니다.\\n";
					continue;
				}
				else if ($_FILES['update_image']['error'][$k] != 0) {
					$file_upload_msg .= "\'{$filename}\' 파일이 정상적으로 업로드 되지 않았습니다.\\n";
					continue;
				}
			}
			*/

			if (is_uploaded_file($tmp_file)) {

				// 프로그램 원래 파일명
				$upload['source'] = $filename;
				$upload['filesize'] = $filesize;

				// 아래의 문자열이 들어간 파일은 -x 를 붙여서 웹경로를 알더라도 실행을 하지 못하도록 함
				$filename = preg_replace("/\.(php|phtm|htm|cgi|pl|exe|jsp|asp|inc)/i", "$0-x", $filename);

				shuffle($chars_array);
				$shuffle = implode("", $chars_array);
				//$upload['file'] = abs(ip2long($_SERVER[REMOTE_ADDR])).'_'.substr($shuffle,0,8).'_'.str_replace('%', '', urlencode($filename));
				$dot = explode(".",$filename);
				$dotnum = count($dot)-1;
				$extension = strtolower($dot[$dotnum]);

				//(18-07-27)파일체크
				$size = GetImageSize($tmp_file);
				list($foo,$width,$bar,$height) = explode("\"",$size[3]);

				//(18-07-27)파일타입제한. siteset 에서 지정한 파일명만 통과
				if (!strstr('|'.$image_type.'|','|'.$extension.'|')) {
					$error_type++;
				}
				//(18-07-27)파일사이즈제한. siteset 에서 지정한 사이즈보다 작은것만 통과
				else if ($filesize > $image_max_size) {
					$error_size++;
				}
				//(18-07-27)파일가로크기제한. siteset 에서 지정한 가로크기보다 작은것만 통과
				else if ($width > $image_max_x) {
					$error_width++;
				}
				else {
					$buffx .= $filename ."|";

					$front = substr(microtime('now'),0,10);
					$upload['file'] = abs(ip2long($_SERVER['REMOTE_ADDR'])).'_'.substr($shuffle,0,8).'_'. $front . "." . $extension;

					// EXIF의 Orientation 데이터가 존재하면 필요에 따라 이미지 파일의 방향을 보정
					$degrees = '0';
					if(!empty($exif['Orientation'])) { //echo "X"; print_r($exif['Orientation']);
						if($extension == "jpg" || $extension == "jpeg"){
							ini_set("gd.jpeg_ignore_warning", 1);
							$image = imagecreatefromjpeg($tmp_file);
						}
						else if($extension == "png"){
							$image = imagecreatefrompng($tmp_file);
						}
						else if($extension == "gif"){
							$image = imagecreatefromgif($tmp_file);
						}

						switch($exif['Orientation']) {
							case 8:
								$image = imagerotate($image,90,0);
								$degrees = '90';
								break;
							case 3:
								$image = imagerotate($image,180,0);
								$degrees = '180';
								break;
							case 6:
								$image = imagerotate($image,-90,0);
								$degrees = '270';
								break;
						}
						//echo " Dg=$degrees ";
					}

					if ($degrees != '0') {

						switch ($extension) {
							case "jpg": case "jpeg":
								imagejpeg($image,$tmp_file);
								break;
							case "png":
								imagePNG($image,$tmp_file,9);
								break;
							case "gif":
								imageGIF($image,$tmp_file);
								break;
						}

					}

					$dest_file = $direct . "/" . $imagepath."/".$upload['file'];

					// 원본이미지용
					$dest_fileA = $direct . "/" . $imagepathA."/".$upload['file'];

					// 썸네일용
					$dest_fileC = $direct . "/" . $imagepathC."/".$upload['file'];

					// 작은이미지2용
					$dest_fileD = $direct . "/" . $imagepathD."/".$upload['file'];

					// DB에 저장할 이미지 경로
					$tmpdest = explode("Bimages/",$dest_file);
					$db_dest = $tmpdest[1];  // db에 저장된다

					// 업로드가 안된다면 에러메세지 출력하고 죽어버립니다.
					$error_code = move_uploaded_file($tmp_file, $dest_file) or die($_FILES['update_image']['error'][$k]);

					// 올라간 파일의 퍼미션을 변경합니다.
					chmod($dest_file, 0606);

					$font_locate = $direct . "/global/NanumGothic.ttf";

					## Ctnales
					$logo = $logoC;
					$string = $stringC; // 이미지에 들어갈 말
					$stand_width = $image_C_x;         // 기준넓이(박스의 가로길이)
					$stand_height = $image_C_y;         // 기준높이(박스의 세로길이)
					$thePath = $dest_fileC;

					list($dst_width,$dst_height) = makeimage($stand_width,$stand_height,$logo,$string,$font_locate,$font_size,$logocolor,$thePath);

					## Dimages
					$logo = $logoD;
					$string = $stringD; // 이미지에 들어갈 말
					$stand_width = $image_D_x;         // 기준넓이(박스의 가로길이)
					$stand_height = $image_D_y;         // 기준높이(박스의 세로길이)
					$thePath = $dest_fileD;

					list($dst_width,$dst_height) = makeimage($stand_width,$stand_height,$logo,$string,$font_locate,$font_size,$logocolor,$thePath);

					## Aimages
					$logo = $logoA;
					$string = $stringA; // 이미지에 들어갈 말
					$stand_width = $image_A_x;         // 기준넓이(박스의 가로길이)
					$stand_height = $image_A_y;         // 기준높이(박스의 세로길이)
					$thePath = $dest_fileA;

					list($dst_width,$dst_height) = makeimage($stand_width,$stand_height,$logo,$string,$font_locate,$font_size,$logocolor,$thePath);

					$Owidth = $dst_width;  // db에 저장된다
					$Oheight = $dst_height;  // db에 저장된다
					#############

					## Bimages
					$logo = $logoB;
					$string = $stringB; // 이미지에 들어갈 말
					$stand_width = $image_B_x;         // 기준넓이(박스의 가로길이)
					$stand_height = $image_B_y;         // 기준높이(박스의 세로길이)
					$thePath = $dest_file;

					list($dst_width,$dst_height) = makeimage($stand_width,$stand_height,$logo,$string,$font_locate,$font_size,$logocolor,$thePath);

					$width = $dst_width;  // db에 저장된다
					$height = $dst_height;  // db에 저장된다

					#######  tmp_pics 디비에 저장 ########
					$dba->basic("insert into tmp_pics
										(
											`tnum`,`id`,
											`picA`,`xA`,`yA`,
											`xB`,`yB`,`rdate`
										)
										values
										(
											\"$tnum\", \"{$_SESSION['mb_id']}\",
											\"$db_dest\",\"$Owidth\", \"$Oheight\",
											\"$width\", \"$height\", Now()
										)");
					############################

					//$imagepath = "./" . $imagepath;

					$imgpath .= "/" . $imagepath."/".$upload['file'] . "|";
				}
			}
		}
	}
}

echo "|*|ok|*|" . $buffx . "|*|" . $imgpath . "|*|" . $error_width . "-" . $image_max_x . "|*|" . $error_size . "-" . $image_max_size . "|*|" . $error_type . "-" . $image_type;
?>