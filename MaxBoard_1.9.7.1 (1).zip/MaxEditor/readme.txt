# MaxEditor 배포본
# 저작자 : 이준규(Max Yi, maxhellovan@gmail.com)

- jQuery가 먼저 선행되어야 함.
- direct 변수가 선행되어야 함. direct 변수는 위치지정을 위해 root 경로로 갈수 있는 위치를 말함. 
ex) var direct = '../..'


//MaxEditor 적용방법

1. 맥스에디터 선언
<head></head> 사이에 아래와 같이 선언해줍니다.
---------------------------------------------------- 
<script>var direct = "[루트기준 맥스에디터위치. 위의 예제참고]";</script>
<link href="[위치]/MaxEditor/css/default.css" type="text/css" rel="stylesheet">
<script src="[위치]/MaxEditor/js/max4.js" charset="utf-8"></script>
---------------------------------------------------- 

1-1. 에디터 세부설정
- 선언문 밑에 <script></script>를 아래와 같이 삽입하고 변수값을 조정합니다.
---------------------------------------------------- 
<script>var direct = "[루트기준 맥스에디터위치. 위의 예제참고]";</script>
<link href="[위치]/MaxEditor/css/default.css" type="text/css" rel="stylesheet">
<script src="[위치]/MaxEditor/js/max4.js" charset="utf-8"></script>

<script>
text_padding = 10; //에디터의 기본 패딩
editor_bgcolor = '#f6f6f6'; //에디터 배경 기본색
editor_radius = 5; //에디터 모서리 라운딩처리 (0이면 직각)
me_lang = "ko"; //언어셋팅(ko:한국어, en:English)
</script>
----------------------------------------------------


2. 에디터를 설치할 div에 'maxeditor 게시판이름' class를 추가합니다. 
- 에디터를 여러개 붙이는 경우: 같은 게시판에 들어갈 것들은 같은 게시판이름을 넣어도 됩니다. 
- 게시판이름은 tablemaster에 생성된 것을 쓰세요.
- 관리자페이지에서 붙이는 경우 sub코드(/Admin/adm_menus_default.html에서 확인)를 쓰세요. 예)'메일발송'페이지에 붙인다면 'sendEmail'이 게시판이름이 됩니다.
---------------------------------------------------- 
<div class='maxeditor 게시판이름1' style='height:에디터높이;'>내용(수정시 사용)</div>
---------------------------------------------------- 


3. 위에서 선언한 div에 편집기 고유id를 추가합니다. (※id는 유니크 해야함)
---------------------------------------------------- 
<div id='고유ID' class='maxeditor 게시판이름1' style='height:에디터높이;'></div>
---------------------------------------------------- 


4. form을 이용해서 넘길 경우 넘겨야하는 내용의 이름이 'content'라면 input을 hidden으로 선언하고 이름을 'content'로 넣습니다.(form으로 넘길때 필요합니다.) 에디터를 설치할 div의 alt에 'content'를 추가합니다. 
---------------------------------------------------- 
<input type='hidden' name='content'>
<div id='고유ID' class='maxeditor 게시판이름' alt='content' style='height:에디터높이;'></div>
---------------------------------------------------- 

4-1. ajax등을 이용해 직접 에디터의 내용을 넘길 경우 alt 생략하고 고유ID값을 넘기뎐 됩니다.
---------------------------------------------------- 
<div id='고유ID' class='maxeditor 게시판이름' alt='content' style='height:에디터높이;'></div>
---------------------------------------------------- 


5. 에디터내용을 넘길때
form을 이용해서 넘길 경우 onclick='pre_chk_data();처리함수;' 의 형식으로 pre_chk_data 함수를 먼저 타게 합니다. 이경우 pre_chk_data 함수에서 '<input type='hidden' name='content'>'에 에디터내용이 자동으로 들어가게 됩니다.
----------------------------------------------------
<button type='button' onclick='pre_chk_data();check_data();'>저장하기</button>
----------------------------------------------------

5-1. ajax등을 이용해 직접 에디터의 내용을 넘길 경우 
고유ID 값으로 div의 내용을 가져가 넘깁니다.
----------------------------------------------------
<script>
var content = document.getElementById('고유ID').innerHTML; //content변수에 에디터내용이 들어갑니다.
or
var content = $('#고유ID').html(); //jQuery를 사용할 경우도 마찬가지입니다.
----------------------------------------------------
